package com.nie.pustaka

import android.content.Context
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Server HTTP mini (socket biasa, tanpa library tambahan) yang membagikan Pustaka ke
 * pengguna lain di Wi-Fi / hotspot yang sama. Mereka membuka http://IP-HP:PORT di browser.
 *
 *  - Halaman web = app.js/style.css yang SAMA dengan yang dipakai di dalam app; bedanya
 *    remote-shim.js menggantikan jembatan `window.Android` dengan panggilan HTTP (/rpc).
 *  - Cover / halaman CBZ / halaman PDF / video dilayani lewat LocalContentInterceptor yang
 *    sama (termasuk HTTP Range untuk seek video).
 *  - BACA: bebas untuk siapa pun yang bisa menjangkau server.
 *  - EDIT: hanya untuk klien yang sudah disetujui pemilik HP (lihat requestEdit/setEdit).
 *
 * KEAMANAN: file chapter di app ini bisa berupa path absolut / content URI, jadi server
 * HANYA melayani cover & chapter yang benar-benar terdaftar di database. Tanpa pengecekan
 * ini, klien bisa meminta file sembarang di HP.
 */
class ShareServer(
    private val appContext: Context,
    private val db: DatabaseHelper,
    private val bridge: WebAppInterface,
    private val interceptor: LocalContentInterceptor,
    /** PIN saat ini (kosong = tanpa PIN). Dibaca setiap request, jadi perubahan langsung berlaku. */
    private val pinProvider: () -> String
) {

    class Client(val id: String) {
        @Volatile var name: String = ""
        @Volatile var ip: String = ""
        @Volatile var canEdit: Boolean = false
        @Volatile var pending: Boolean = false
        @Volatile var denied: Boolean = false
        @Volatile var lastSeen: Long = 0L
    }

    /** Dipanggil (di thread server) saat klien menekan "Minta izin edit". */
    var onEditRequested: ((Client) -> Unit)? = null

    @Volatile var isRunning: Boolean = false
        private set
    @Volatile var port: Int = 0
        private set

    private val clients = ConcurrentHashMap<String, Client>()

    // ---- PIN: sesi login (token di cookie) & pembatasan percobaan salah per IP ----
    private val sessions: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private class Fail { var count = 0; var lockUntil = 0L }
    private val fails = ConcurrentHashMap<String, Fail>()
    private val rng = SecureRandom()
    private var serverSocket: ServerSocket? = null
    private var pool: ExecutorService? = null

    companion object {
        private const val MAX_BODY = 30L * 1024 * 1024 // cover base64
        private const val ACTIVE_WINDOW_MS = 15L * 60 * 1000
        private val ID_RE = Regex("^[a-f0-9]{16,64}$")

        private val ASSETS = mapOf(
            "/" to ("index.html" to "text/html; charset=utf-8"),
            "/index.html" to ("index.html" to "text/html; charset=utf-8"),
            "/app.js" to ("app.js" to "application/javascript; charset=utf-8"),
            "/style.css" to ("style.css" to "text/css; charset=utf-8"),
            "/remote-shim.js" to ("remote-shim.js" to "application/javascript; charset=utf-8")
        )

        /** Aman untuk siapa saja yang terhubung (hanya membaca). */
        private val READ_METHODS = setOf(
            "listCollections", "getDetail", "listCategories", "listBookmarks",
            "getChapterInfo", "getChapterIdByFileName", "hasManageStoragePermission"
        )

        /** Mengubah data -> butuh izin edit dari pemilik. */
        private val WRITE_METHODS = setOf(
            "addCollection", "editCollection", "deleteCollection", "updateItemCategories",
            "addCategory", "deleteCategory", "editChapters", "deleteChapter",
            "addBookmark", "deleteBookmark"
        )
    }

    // ------------------------------------------------------------------ lifecycle

    @Synchronized
    fun start(preferredPort: Int = 8080): Boolean {
        if (isRunning) return true
        var bound: ServerSocket? = null
        for (p in preferredPort..preferredPort + 10) {
            val s = ServerSocket()
            try {
                s.reuseAddress = true
                s.bind(InetSocketAddress(p))
                bound = s
                break
            } catch (_: IOException) {
                try { s.close() } catch (_: Exception) {}
            }
        }
        val socket = bound ?: return false
        serverSocket = socket
        port = socket.localPort
        pool = Executors.newCachedThreadPool()
        isRunning = true
        Thread({ acceptLoop(socket) }, "pustaka-share-accept").start()
        return true
    }

    @Synchronized
    fun stop() {
        isRunning = false
        try { serverSocket?.close() } catch (_: Exception) {}
        serverSocket = null
        pool?.shutdownNow()
        pool = null
        clients.clear()
    }

    private fun acceptLoop(s: ServerSocket) {
        while (isRunning) {
            try {
                val sock = s.accept()
                val p = pool
                if (p == null) { sock.close(); continue }
                p.execute { handle(sock) }
            } catch (_: Exception) {
                if (!isRunning) break
                try { Thread.sleep(100) } catch (_: InterruptedException) { break }
            }
        }
    }

    // ------------------------------------------------------------------ PIN

    fun pinRequired(): Boolean = pinProvider().isNotEmpty()

    /** Dipanggil saat PIN diganti/dihapus: semua browser harus login ulang. */
    fun invalidateSessions() { sessions.clear() }

    private fun cookieToken(h: Map<String, String>): String? =
        h["cookie"]?.split(';')?.map { it.trim() }
            ?.firstOrNull { it.startsWith("pk_token=") }?.substringAfter('=')

    private fun isAuthed(h: Map<String, String>): Boolean {
        if (!pinRequired()) return true
        val t = cookieToken(h) ?: return false
        return sessions.contains(t)
    }

    private fun handleLogin(body: ByteArray, sock: Socket, out: OutputStream) {
        val real = pinProvider()
        if (real.isEmpty()) return writeJson(out, 200, JSONObject().put("ok", true)) // tanpa PIN, tak perlu login
        val ip = sock.inetAddress?.hostAddress ?: "?"
        val f = fails.getOrPut(ip) { Fail() }
        val now = System.currentTimeMillis()
        synchronized(f) {
            if (now < f.lockUntil) {
                val wait = (f.lockUntil - now) / 1000 + 1
                return writeJson(out, 429, JSONObject().put("error", "locked").put("retry_s", wait))
            }
            val pin = try {
                JSONObject(String(body, Charsets.UTF_8)).optString("pin", "")
            } catch (_: Exception) { "" }
            if (MessageDigest.isEqual(pin.toByteArray(Charsets.UTF_8), real.toByteArray(Charsets.UTF_8))) {
                f.count = 0
                val raw = ByteArray(16).also { rng.nextBytes(it) }
                val token = raw.joinToString("") { "%02x".format(it) }
                if (sessions.size > 1000) sessions.clear()
                sessions.add(token)
                return writeJson(
                    out, 200, JSONObject().put("ok", true),
                    listOf("Set-Cookie: pk_token=$token; Path=/; HttpOnly; SameSite=Lax; Max-Age=604800")
                )
            }
            f.count++
            if (f.count >= 5) { f.count = 0; f.lockUntil = now + 60_000 }
            return writeJson(out, 401, JSONObject().put("error", "wrong").put("left", 5 - f.count))
        }
    }

    // ------------------------------------------------------------------ host-side API

    fun clientsSnapshot(): List<Client> {
        val now = System.currentTimeMillis()
        return clients.values
            .filter { it.canEdit || it.pending || now - it.lastSeen < ACTIVE_WINDOW_MS }
            .sortedWith(compareByDescending<Client> { it.pending }.thenByDescending { it.lastSeen })
    }

    fun pendingClients(): List<Client> = clients.values.filter { it.pending }.sortedBy { it.lastSeen }

    /** Pemilik menyetujui / menolak / mencabut izin edit. */
    fun setEdit(id: String, allowed: Boolean): Boolean {
        val c = clients[id] ?: return false
        c.denied = !allowed && c.pending
        c.canEdit = allowed
        c.pending = false
        return true
    }

    /** Alamat yang bisa diketik pengguna lain (Wi-Fi & hotspot). */
    fun urls(): List<String> {
        val list = ArrayList<String>()
        try {
            val ifs = NetworkInterface.getNetworkInterfaces() ?: return list
            for (nif in ifs) {
                if (!nif.isUp || nif.isLoopback) continue
                val n = nif.name.lowercase()
                if (n.startsWith("rmnet") || n.startsWith("ccmni") || n.startsWith("dummy") || n.startsWith("tun")) continue
                for (addr in nif.inetAddresses) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress && addr.isSiteLocalAddress) {
                        list.add("http://${addr.hostAddress}:$port")
                    }
                }
            }
        } catch (_: Exception) {
        }
        return list
    }

    // ------------------------------------------------------------------ connection handling

    private fun handle(sock: Socket) {
        try {
            sock.soTimeout = 30_000
            sock.tcpNoDelay = true
            val input = BufferedInputStream(sock.getInputStream(), 8192)
            val out = BufferedOutputStream(sock.getOutputStream(), 16384)

            val requestLine = readLine(input) ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return
            val method = parts[0].uppercase()
            val target = parts[1]

            val headers = HashMap<String, String>()
            while (true) {
                val line = readLine(input) ?: break
                if (line.isEmpty()) break
                val i = line.indexOf(':')
                if (i > 0) headers[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
                if (headers.size > 100) return
            }

            var body = ByteArray(0)
            val len = headers["content-length"]?.toLongOrNull() ?: 0L
            if (len > MAX_BODY) {
                writeText(out, 413, "text/plain", "Terlalu besar")
                return
            }
            if (len > 0) body = readFully(input, len.toInt())

            route(method, target, headers, body, sock, out)
            out.flush()
        } catch (_: Exception) {
            // klien memutus koneksi (umum saat seek video) -- abaikan
        } finally {
            try { sock.close() } catch (_: Exception) {}
        }
    }

    private fun route(
        method: String, target: String, h: Map<String, String>,
        body: ByteArray, sock: Socket, out: OutputStream
    ) {
        val path = target.substringBefore('?')
        if (method != "GET" && method != "HEAD" && method != "POST") {
            writeText(out, 405, "text/plain", "Metode tidak didukung")
            return
        }
        val head = method == "HEAD"

        if (method == "POST") {
            if (path == "/api/login") { handleLogin(body, sock, out); return }
            if (!isAuthed(h)) { writeJson(out, 401, JSONObject().put("error", "locked")); return }
            when (path) {
                "/rpc" -> handleRpc(h, body, sock, out)
                "/api/request-edit" -> handleRequestEdit(h, body, sock, out)
                else -> writeText(out, 404, "text/plain", "Tidak ditemukan")
            }
            return
        }

        val asset = ASSETS[path]
        val isPage = path == "/" || path == "/index.html"
        val authed = isAuthed(h)
        when {
            // Terkunci: halaman utama diganti layar PIN; app.js/style.css tidak berisi data sehingga tetap publik.
            isPage && !authed -> serveAsset(out, "login.html", "text/html; charset=utf-8", head)
            asset != null -> serveAsset(out, asset.first, asset.second, head)
            path == "/api/status" ->
                if (authed) handleStatus(h, sock, out) else writeJson(out, 401, JSONObject().put("error", "locked"))
            path == "/favicon.ico" -> writeBytes(out, 204, ByteArray(0), "image/x-icon")
            path.startsWith("/cover/") || path.startsWith("/chapter/") ||
                path.startsWith("/cbzpage/") || path.startsWith("/pdfpage/") ->
                if (authed) serveMedia(path, h, out, head) else writeText(out, 401, "text/plain", "Terkunci")
            else -> writeText(out, 404, "text/plain", "Tidak ditemukan")
        }
    }

    // ------------------------------------------------------------------ static assets & media

    private fun serveAsset(out: OutputStream, name: String, mime: String, head: Boolean) {
        val bytes = try {
            appContext.assets.open("www/$name").use { it.readBytes() }
        } catch (_: Exception) {
            writeText(out, 404, "text/plain", "Aset tidak ada")
            return
        }
        writeBytes(out, 200, if (head) ByteArray(0) else bytes, mime, contentLength = bytes.size.toLong())
    }

    private fun isKnownCover(relPath: String): Boolean =
        relPath.isNotEmpty() && exists("SELECT 1 FROM collection WHERE image_path = ? LIMIT 1", relPath)

    private fun isKnownChapter(fileName: String): Boolean =
        fileName.isNotEmpty() && exists("SELECT 1 FROM chapter_list WHERE file_name = ? LIMIT 1", fileName)

    private fun exists(sql: String, arg: String): Boolean =
        db.readableDatabase.rawQuery(sql, arrayOf(arg)).use { it.moveToFirst() }

    private fun serveMedia(path: String, h: Map<String, String>, out: OutputStream, head: Boolean) {
        // Path dikirim apa adanya (masih ter-encode) supaya Uri.pathSegments mendekode persis
        // seperti yang dilakukan WebView di dalam app.
        val uri = Uri.parse("https://${LocalContentInterceptor.HOST}$path")
        val segs = uri.pathSegments
        if (segs.size < 2) { writeText(out, 404, "text/plain", "Tidak ditemukan"); return }

        val allowed = when (segs[0]) {
            "cover" -> isKnownCover(segs.drop(1).joinToString("/"))
            "chapter" -> isKnownChapter(segs.drop(1).joinToString("/"))
            "cbzpage", "pdfpage" ->
                segs.size >= 3 && isKnownChapter(segs.subList(1, segs.size - 1).joinToString("/"))
            else -> false
        }
        if (!allowed) { writeText(out, 404, "text/plain", "Tidak ditemukan"); return }

        val reqHeaders = HashMap<String, String>()
        h["range"]?.let { reqHeaders["Range"] = it }
        val resp = interceptor.intercept(FakeRequest(uri, reqHeaders))
        if (resp == null) { writeText(out, 404, "text/plain", "Tidak ditemukan"); return }
        writeWebResponse(out, resp, head)
    }

    private class FakeRequest(private val u: Uri, private val hdrs: Map<String, String>) : WebResourceRequest {
        override fun getUrl(): Uri = u
        override fun isForMainFrame(): Boolean = false
        override fun isRedirect(): Boolean = false
        override fun hasGesture(): Boolean = false
        override fun getMethod(): String = "GET"
        override fun getRequestHeaders(): Map<String, String> = hdrs
    }

    // ------------------------------------------------------------------ API: status / izin edit / rpc

    private fun clientFor(h: Map<String, String>, sock: Socket): Client? {
        val id = h["x-client"] ?: return null
        if (!ID_RE.matches(id)) return null
        val c = clients.getOrPut(id) { Client(id) }
        c.ip = sock.inetAddress?.hostAddress ?: ""
        c.lastSeen = System.currentTimeMillis()
        if (clients.size > 200) {
            val now = System.currentTimeMillis()
            clients.values.filter { !it.canEdit && !it.pending && now - it.lastSeen > ACTIVE_WINDOW_MS }
                .forEach { clients.remove(it.id) }
        }
        return c
    }

    private fun handleStatus(h: Map<String, String>, sock: Socket, out: OutputStream) {
        val c = clientFor(h, sock) ?: return writeJson(out, 400, JSONObject().put("error", "no_client"))
        writeJson(
            out, 200, JSONObject()
                .put("can_edit", c.canEdit).put("pending", c.pending)
                .put("denied", c.denied).put("name", c.name)
        )
    }

    private fun handleRequestEdit(h: Map<String, String>, body: ByteArray, sock: Socket, out: OutputStream) {
        val c = clientFor(h, sock) ?: return writeJson(out, 400, JSONObject().put("error", "no_client"))
        val rawName = try {
            JSONObject(String(body, Charsets.UTF_8)).optString("name", "")
        } catch (_: Exception) { "" }
        val name = rawName.replace(Regex("\\p{Cntrl}"), "").trim().take(40)
        c.name = if (name.isEmpty()) "Tanpa nama" else name
        if (!c.canEdit && !c.pending) {
            c.denied = false
            c.pending = true
            try { onEditRequested?.invoke(c) } catch (_: Exception) {}
        }
        writeJson(out, 200, JSONObject().put("pending", c.pending).put("can_edit", c.canEdit))
    }

    private fun handleRpc(h: Map<String, String>, body: ByteArray, sock: Socket, out: OutputStream) {
        val c = clientFor(h, sock) ?: return writeJson(out, 400, JSONObject().put("error", "no_client"))
        val req = try {
            JSONObject(String(body, Charsets.UTF_8))
        } catch (_: Exception) {
            return writeJson(out, 400, JSONObject().put("error", "bad_request"))
        }
        val m = req.optString("m", "")
        val a = req.optJSONArray("a") ?: JSONArray()

        val isWrite = m in WRITE_METHODS
        if (!isWrite && m !in READ_METHODS) {
            return writeJson(out, 404, JSONObject().put("error", "unknown_method"))
        }
        if (isWrite && !c.canEdit) {
            return writeJson(out, 403, JSONObject().put("error", "forbidden"))
        }
        val result = try {
            invoke(m, a)
        } catch (e: Exception) {
            return writeJson(out, 500, JSONObject().put("error", "failed").put("message", e.message ?: ""))
        }
        writeBytes(out, 200, result.toByteArray(Charsets.UTF_8), "text/plain; charset=utf-8")
    }

    private fun invoke(m: String, a: JSONArray): String = when (m) {
        "listCollections" -> bridge.listCollections(
            a.optString(0, ""), a.optString(1, ""), a.optString(2, ""),
            a.optString(3, ""), a.optString(4, ""), a.optString(5, "")
        )
        "getDetail" -> bridge.getDetail(a.optInt(0))
        "listCategories" -> bridge.listCategories()
        "listBookmarks" -> bridge.listBookmarks(a.optInt(0))
        "getChapterInfo" -> {
            val f = a.optString(0, "")
            if (isKnownChapter(f)) bridge.getChapterInfo(f)
            else JSONObject().put("error", "not_found").toString()
        }
        "getChapterIdByFileName" -> bridge.getChapterIdByFileName(a.optString(0, ""))
        "hasManageStoragePermission" -> bridge.hasManageStoragePermission().toString()

        "addCollection" -> bridge.addCollection(a.optString(0, "{}"))
        "editCollection" -> bridge.editCollection(a.optInt(0), a.optString(1, "{}"))
        "deleteCollection" -> bridge.deleteCollection(a.optInt(0))
        "updateItemCategories" -> bridge.updateItemCategories(a.optInt(0), a.optBoolean(1), a.optString(2, ""))
        "addCategory" -> bridge.addCategory(a.optString(0, ""))
        "deleteCategory" -> bridge.deleteCategory(a.optInt(0))
        "editChapters" -> bridge.editChapters(a.optString(0, "[]"))
        "deleteChapter" -> bridge.deleteChapter(a.optInt(0))
        "addBookmark" -> bridge.addBookmark(a.optInt(0), a.optInt(1), a.optInt(2))
        "deleteBookmark" -> bridge.deleteBookmark(a.optInt(0))
        else -> throw IllegalArgumentException("unknown method")
    }

    // ------------------------------------------------------------------ HTTP writing helpers

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = input.read()
            if (b == -1) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) break
            if (b != '\r'.code) sb.append(b.toChar())
            if (sb.length > 16384) throw IOException("header terlalu panjang")
        }
        return sb.toString()
    }

    private fun readFully(input: InputStream, n: Int): ByteArray {
        val buf = ByteArray(n)
        var off = 0
        while (off < n) {
            val r = input.read(buf, off, n - off)
            if (r < 0) throw IOException("koneksi terputus")
            off += r
        }
        return buf
    }

    private fun reasonFor(status: Int): String = when (status) {
        200 -> "OK"; 204 -> "No Content"; 206 -> "Partial Content"
        400 -> "Bad Request"; 401 -> "Unauthorized"; 403 -> "Forbidden"; 404 -> "Not Found"
        429 -> "Too Many Requests"
        405 -> "Method Not Allowed"; 413 -> "Payload Too Large"; 416 -> "Range Not Satisfiable"
        500 -> "Internal Server Error"; else -> "OK"
    }

    private fun writeBytes(
        out: OutputStream, status: Int, bytes: ByteArray, mime: String, contentLength: Long = -1L,
        extraHeaders: List<String> = emptyList()
    ) {
        val sb = StringBuilder()
        sb.append("HTTP/1.1 ").append(status).append(' ').append(reasonFor(status)).append("\r\n")
        sb.append("Content-Type: ").append(mime).append("\r\n")
        sb.append("Content-Length: ").append(if (contentLength >= 0) contentLength else bytes.size.toLong()).append("\r\n")
        sb.append("Cache-Control: no-store\r\n")
        sb.append("X-Content-Type-Options: nosniff\r\n")
        extraHeaders.forEach { sb.append(it).append("\r\n") }
        sb.append("Connection: close\r\n\r\n")
        out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
        if (bytes.isNotEmpty()) out.write(bytes)
        out.flush()
    }

    private fun writeText(out: OutputStream, status: Int, mime: String, text: String) =
        writeBytes(out, status, text.toByteArray(Charsets.UTF_8), "$mime; charset=utf-8")

    private fun writeJson(out: OutputStream, status: Int, obj: JSONObject, extraHeaders: List<String> = emptyList()) =
        writeBytes(out, status, obj.toString().toByteArray(Charsets.UTF_8), "application/json; charset=utf-8",
            extraHeaders = extraHeaders)

    /** Salin WebResourceResponse (hasil LocalContentInterceptor) ke socket, termasuk header Range/Content-Length. */
    private fun writeWebResponse(out: OutputStream, resp: WebResourceResponse, head: Boolean) {
        val sb = StringBuilder()
        sb.append("HTTP/1.1 ").append(resp.statusCode).append(' ')
            .append(resp.reasonPhrase ?: reasonFor(resp.statusCode)).append("\r\n")
        sb.append("Content-Type: ").append(resp.mimeType ?: "application/octet-stream")
        resp.encoding?.let { sb.append("; charset=").append(it) }
        sb.append("\r\n")
        resp.responseHeaders?.forEach { (k, v) -> sb.append(k).append(": ").append(v).append("\r\n") }
        sb.append("X-Content-Type-Options: nosniff\r\n")
        sb.append("Connection: close\r\n\r\n")
        out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
        val data = resp.data
        try {
            if (!head && data != null) data.copyTo(out, 65536)
        } finally {
            try { data?.close() } catch (_: Exception) {}
        }
        out.flush()
    }
}

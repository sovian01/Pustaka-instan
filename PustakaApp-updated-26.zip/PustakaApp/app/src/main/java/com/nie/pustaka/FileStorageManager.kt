package com.nie.pustaka

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.InputStream
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

/**
 * Pengganti langsung dari get_storage_base() / find_file() di Flask, DITAMBAH
 * dukungan "Folder Chapter" yang dipilih user sendiri lewat System Folder Picker
 * (Storage Access Framework / SAF).
 *
 * PERUBAHAN PENTING (perbaikan bug "APK/penyimpanan membengkak" & "layar hitam"):
 * File CHAPTER (pdf/txt/mp4/cbz) TIDAK PERNAH lagi disalin ke dalam penyimpanan
 * milik app. App hanya menyimpan REFERENSI (path relatif terhadap folder yang
 * dipilih user) di database, lalu membaca langsung dari folder itu setiap kali
 * dibutuhkan -- persis seperti "hanya membaca file yang saya simpan di folder
 * tertentu" yang diminta user. Ini juga yang menghilangkan bug layar hitam,
 * karena isi file besar tidak pernah lagi dibaca penuh ke memori lalu dikirim
 * lewat JS bridge sebagai base64 raksasa.
 *
 * Cover gambar (uploads) TIDAK diubah -- ukurannya kecil, tetap disimpan seperti
 * semula (internal/eksternal, sesuai pilihan user di form).
 */
class FileStorageManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("pustaka_settings", Context.MODE_PRIVATE)

    private val internalBase: File
        get() {
            val base = File(context.getExternalFilesDir(null), "Pustaka")
            base.mkdirs()
            return base
        }

    /** Folder shared publik, dipakai kalau user memilih "eksternal" untuk COVER. */
    private val externalBase: File
        get() = File(Environment.getExternalStorageDirectory(), "Pustaka")

    /**
     * SEBELUMNYA fungsi ini selalu balikan `true` untuk semua versi Android di bawah 11 --
     * padahal WRITE_EXTERNAL_STORAGE adalah izin "berbahaya" (dangerous permission) yang
     * di Android 6.0-9.0 (API 23-28) WAJIB diminta lewat dialog runtime (bukan cukup
     * dideklarasikan di manifest), dan TIDAK OTOMATIS diberikan saat instal. Akibatnya
     * kode di sini mengira sudah punya akses padahal belum, dan menyimpan cover ke
     * "Eksternal Storage" bisa gagal (SecurityException) di rentang versi itu.
     */
    fun hasManageStoragePermission(): Boolean {
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            androidx.core.content.ContextCompat.checkSelfPermission(
                context, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        }
    }

    /** Setara get_storage_base(choice) -- HANYA untuk cover gambar. */
    fun getStorageBase(choice: String): File {
        if (choice == "eksternal" && hasManageStoragePermission()) {
            try {
                val dir = externalBase
                dir.mkdirs()
                if (dir.canWrite()) return dir
            } catch (_: Exception) {
                // fallback ke internal, sama seperti try/except Python
            }
        }
        val dir = internalBase
        dir.mkdirs()
        return dir
    }

    /** Cover: cek internal dulu, lalu eksternal. */
    fun findFile(relativePath: String?, subfolder: String): File? {
        if (relativePath.isNullOrEmpty()) return null
        val intPath = File(File(internalBase, subfolder), relativePath)
        if (intPath.exists()) return intPath
        val extPath = File(File(externalBase, subfolder), relativePath)
        if (extPath.exists()) return extPath
        return null
    }

    fun ensureDefaultFolders() {
        File(internalBase, "uploads").mkdirs()
    }

    /** PIN akses server berbagi (kosong = tanpa PIN). Hanya dibaca pemilik & ShareServer. */
    fun getSharePin(): String = prefs.getString("share_pin", "") ?: ""
    fun setSharePin(pin: String) { prefs.edit().putString("share_pin", pin).apply() }

    /** Simpan bytes cover, kembalikan nama file relatif yang disimpan ke DB. */
    fun saveFile(bytes: ByteArray, storageChoice: String, subfolder: String, fileName: String): String {
        val base = getStorageBase(storageChoice)
        val dir = File(base, subfolder)
        dir.mkdirs()
        val safeName = sanitizeFileName(fileName)
        val out = File(dir, safeName)
        out.writeBytes(bytes)
        return safeName
    }

    fun deleteFile(relativePath: String?, subfolder: String) {
        val f = findFile(relativePath, subfolder) ?: return
        try { f.delete() } catch (_: Exception) {}
    }

    fun sanitizeFileName(name: String): String {
        return name.replace(Regex("[^A-Za-z0-9._\\- ]"), "_").trim()
    }

    /**
     * Referensi chapter BARU (lewat picker file tunggal SAF) disimpan sebagai satu string
     * "content://...|nama_asli.ext" -- bagian setelah "|" adalah nama file asli, dipakai
     * untuk mendeteksi ekstensi karena content URI sendiri belum tentu berakhiran ekstensi
     * yang jelas (mis. penyedia dokumen dgn id internal). Referensi LAMA (relatif thd
     * Folder Chapter, tanpa "|") tetap dikenali apa adanya lewat fallback ini.
     */
    fun displayNameOf(raw: String): String = if (raw.contains('|')) raw.substringAfterLast('|') else raw

    fun extensionOf(raw: String): String = displayNameOf(raw).substringAfterLast('.', "").lowercase()

    fun mimeTypeFor(name: String): String {
        return when (extensionOf(name)) {
            "png" -> "image/png"
            "webp" -> "image/webp"
            "jpg", "jpeg" -> "image/jpeg"
            "pdf" -> "application/pdf"
            "mp4" -> "video/mp4"
            "txt" -> "text/plain"
            else -> "application/octet-stream"
        }
    }

    /** Sama seperti daftar accept=".pdf,.txt,.mp4,.cbz" pada form upload versi Flask. */
    fun isSupportedChapterExt(name: String): Boolean {
        return extensionOf(name) in setOf("pdf", "txt", "mp4", "cbz")
    }

    // -----------------------------------------------------------------
    // FOLDER CHAPTER (baru): dipilih user sendiri, file tidak pernah disalin
    // -----------------------------------------------------------------

    fun getChapterFolderUri(): Uri? {
        val s = prefs.getString("chapter_tree_uri", null) ?: return null
        return try { Uri.parse(s) } catch (_: Exception) { null }
    }

    fun setChapterFolder(treeUri: Uri) {
        prefs.edit().putString("chapter_tree_uri", treeUri.toString()).apply()
    }

    fun hasChapterFolder(): Boolean = getChapterFolderUri() != null

    /** Path asli kalau folder yang dipilih ada di storage utama (paling umum) -- baca cepat via java.io.File. */
    private fun resolvePrimaryPath(treeUri: Uri): File? {
        return try {
            val docId = DocumentsContract.getTreeDocumentId(treeUri)
            val split = docId.split(":")
            if (split.isEmpty() || !split[0].equals("primary", ignoreCase = true)) return null
            val relative = if (split.size > 1) split[1] else ""
            val base = Environment.getExternalStorageDirectory()
            val dir = if (relative.isEmpty()) base else File(base, relative)
            if (dir.exists()) dir else null
        } catch (_: Exception) {
            null
        }
    }

    /** Nama folder yang ditampilkan ke user di UI (path asli kalau bisa, atau nama folder SAF). */
    fun getChapterFolderLabel(): String {
        val uri = getChapterFolderUri() ?: return ""
        resolvePrimaryPath(uri)?.let { return it.absolutePath }
        return try {
            DocumentFile.fromTreeUri(context, uri)?.name ?: uri.lastPathSegment ?: uri.toString()
        } catch (_: Exception) {
            uri.toString()
        }
    }

    data class ChapterEntry(val name: String, val isDirectory: Boolean, val relativePath: String)

    /** Daftar folder & file (yang didukung) di dalam folder chapter, pada sub-path tertentu. */
    fun listChapterEntries(subPath: String): List<ChapterEntry> {
        val uri = getChapterFolderUri() ?: return emptyList()

        resolvePrimaryPath(uri)?.let { root ->
            val dir = if (subPath.isEmpty()) root else File(root, subPath)
            val files = dir.listFiles() ?: return emptyList()
            return files
                .filter { it.isDirectory || isSupportedChapterExt(it.name) }
                .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
                .map { ChapterEntry(it.name, it.isDirectory, if (subPath.isEmpty()) it.name else "$subPath/${it.name}") }
        }

        // Fallback SAF (mis. folder di kartu SD lepasan yang tidak bisa dipetakan ke path asli)
        return try {
            var dirDoc = DocumentFile.fromTreeUri(context, uri) ?: return emptyList()
            if (subPath.isNotEmpty()) {
                for (seg in subPath.split("/")) {
                    dirDoc = dirDoc.listFiles().firstOrNull { it.name == seg && it.isDirectory } ?: return emptyList()
                }
            }
            dirDoc.listFiles()
                .filter { it.isDirectory || isSupportedChapterExt(it.name ?: "") }
                .sortedWith(compareBy({ !it.isDirectory }, { (it.name ?: "").lowercase() }))
                .map { ChapterEntry(it.name ?: "?", it.isDirectory, if (subPath.isEmpty()) (it.name ?: "?") else "$subPath/${it.name}") }
        } catch (_: Exception) {
            emptyList()
        }
    }

    /** Representasi sebuah file chapter yang berhasil ditemukan, baik lewat path asli maupun SAF. */
    sealed class ChapterSource {
        data class Path(val file: File) : ChapterSource()
        data class Doc(val uri: Uri) : ChapterSource()
    }

    /**
     * Kalau URI dokumen TUNGGAL (hasil ACTION_OPEN_DOCUMENT, bukan tree) sebenarnya
     * menunjuk ke file di penyimpanan utama (kasus paling umum saat user memilih file
     * lewat "Pilih File..."), kembalikan path aslinya. Ini PENTING untuk performa &
     * keandalan: java.io.File/ParcelFileDescriptor.open() memberi akses random-access
     * sungguhan, sedangkan fd dari ContentResolver ke beberapa penyedia dokumen kadang
     * berupa pipe berurutan yang lambat/tidak seekable -- itulah penyebab render PDF
     * gagal (layar hitam) & CBZ besar terasa sangat lambat kalau dipaksa lewat sana.
     */
    private fun resolvePrimaryPathForSingleDocument(uri: Uri): File? {
        return try {
            val docId = DocumentsContract.getDocumentId(uri)
            val split = docId.split(":")
            if (split.isEmpty() || !split[0].equals("primary", ignoreCase = true)) return null
            val relative = if (split.size > 1) split[1] else ""
            if (relative.isEmpty()) return null
            val file = File(Environment.getExternalStorageDirectory(), relative)
            if (file.exists()) file else null
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Path asli (kalau bisa dipetakan) dari sebuah content URI dokumen TUNGGAL yang baru
     * dipilih user lewat picker file. Dipakai SAAT MEMILIH file (bukan saat membaca), supaya
     * kalau app sudah punya izin "Kelola Semua File" (MANAGE_EXTERNAL_STORAGE), alamat file
     * yang DISIMPAN ke database langsung berupa path asli -- dibaca selamanya lewat
     * java.io.File biasa, PERSIS seperti folder "static" di Flask, tanpa SAF/ContentResolver
     * sama sekali. Ini jauh lebih andal & cepat untuk file besar (100MB+) dibanding content
     * URI, yang pada sebagian penyedia dokumen hanya memberi akses baca berurutan (pipe)
     * yang lambat/tidak seekable -- penyebab render PDF/CBZ besar gagal atau lambat.
     */
    fun realAbsolutePathFor(uri: Uri): String? = resolvePrimaryPathForSingleDocument(uri)?.absolutePath

    /**
     * Cari file chapter berdasarkan path relatif yang tersimpan di DB.
     * Urutan pencarian: alamat file asli (path mentah, lihat realAbsolutePathFor) ->
     * content URI langsung -> folder chapter yang dikonfigurasi user -> (kompatibilitas
     * lama) folder "chapters" bawaan app untuk chapter yang diunggah sebelum update ini.
     */
    fun resolveChapterSource(relativePath: String?): ChapterSource? {
        if (relativePath.isNullOrEmpty()) return null

        val addressPart = relativePath.substringBefore('|')

        // PALING BARU & PALING ANDAL: alamat file asli di penyimpanan (disimpan sejak
        // izin "Kelola Semua File" aktif saat file dipilih) -- baca langsung lewat
        // java.io.File, tanpa lapisan SAF/ContentResolver apa pun.
        if (addressPart.startsWith("/")) {
            val f = File(addressPart)
            return if (f.exists()) ChapterSource.Path(f) else null
        }

        // BARU: referensi langsung ke SATU file yang dipilih user lewat picker file
        // (bukan folder). App tidak pernah menjelajahi/membaca isi folder apa pun --
        // hanya membuka alamat (content URI) file ini langsung, setiap dibutuhkan.
        val uriPart = addressPart
        if (uriPart.startsWith("content://")) {
            return try {
                val uri = Uri.parse(uriPart)
                resolvePrimaryPathForSingleDocument(uri)?.let { return ChapterSource.Path(it) }
                val doc = DocumentFile.fromSingleUri(context, uri)
                if (doc != null && doc.exists()) ChapterSource.Doc(uri) else null
            } catch (_: Exception) {
                null
            }
        }

        getChapterFolderUri()?.let { uri ->
            resolvePrimaryPath(uri)?.let { root ->
                val f = File(root, relativePath)
                if (f.exists()) return ChapterSource.Path(f)
            }
            try {
                var doc = DocumentFile.fromTreeUri(context, uri)
                for (seg in relativePath.split("/")) {
                    doc = doc?.listFiles()?.firstOrNull { it.name == seg }
                }
                if (doc != null && doc.exists()) return ChapterSource.Doc(doc.uri)
            } catch (_: Exception) { /* lanjut ke fallback lama */ }
        }

        // Kompatibilitas lama: chapter yang sempat disalin ke storage app sebelum update ini.
        findFile(relativePath, "chapters")?.let { return ChapterSource.Path(it) }
        File(File(externalBase, "chapters"), relativePath).let { if (it.exists()) return ChapterSource.Path(it) }
        return null
    }

    fun openStream(source: ChapterSource): InputStream? = when (source) {
        is ChapterSource.Path -> source.file.inputStream()
        is ChapterSource.Doc -> context.contentResolver.openInputStream(source.uri)
    }

    fun openParcelFileDescriptor(source: ChapterSource): ParcelFileDescriptor? = when (source) {
        is ChapterSource.Path -> ParcelFileDescriptor.open(source.file, ParcelFileDescriptor.MODE_READ_ONLY)
        is ChapterSource.Doc -> context.contentResolver.openFileDescriptor(source.uri, "r")
    }

    fun readTextFile(source: ChapterSource): String {
        return openStream(source)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
    }

    /**
     * Nama entri gambar di dalam .cbz/.zip, URUT ABJAD -- persis seperti
     * `sorted([f for f in z.namelist() if ...])` di versi Flask. Arsip CBZ
     * tidak selalu MENYIMPAN entrinya sudah urut secara fisik di dalam zip,
     * jadi membaca apa adanya sesuai urutan mentah zip (seperti sebelumnya)
     * bisa membuat urutan halaman berantakan dibanding versi Python.
     *
     * Kalau file-nya berupa java.io.File biasa (ChapterSource.Path), dipakai
     * java.util.zip.ZipFile yang random-access lewat central directory arsip --
     * daftar & isi entri langsung didapat tanpa membaca ulang seluruh arsip dari
     * awal. Ini PENTING untuk chapter besar: sebelumnya tiap halaman membaca ulang
     * arsip dari awal lewat ZipInputStream (harus melewati semua entri sebelumnya
     * satu per satu), jadi makin ke belakang makin lambat -- bisa sampai terasa
     * macet/layar hitam pada CBZ berukuran besar. ZipInputStream (lambat, hanya
     * baca berurutan) tetap dipakai sebagai fallback untuk ChapterSource.Doc
     * (mis. file dari kartu SD lepasan/penyedia dokumen lain yang tidak bisa
     * dipetakan ke path asli).
     */
    private fun sortedImageEntryNames(source: ChapterSource): List<String> = when (source) {
        is ChapterSource.Path -> ZipFile(source.file).use { zip ->
            zip.entries().asSequence()
                .filter { !it.isDirectory && isImageEntry(it.name) }
                .map { it.name }
                .sorted().toList()
        }
        is ChapterSource.Doc -> {
            val stream = openStream(source)
            if (stream == null) emptyList() else {
                val names = mutableListOf<String>()
                ZipInputStream(stream).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory && isImageEntry(entry.name)) names.add(entry.name)
                        entry = zip.nextEntry
                    }
                }
                names.sorted()
            }
        }
    }

    /** Hitung jumlah halaman gambar di dalam .cbz/.zip. */
    fun cbzPageCount(source: ChapterSource): Int = sortedImageEntryNames(source).size

    /** Ambil satu halaman gambar dari .cbz/.zip sebagai bytes, berdasarkan urutan abjad (bukan urutan fisik zip). */
    fun cbzPageBytes(source: ChapterSource, index: Int): Pair<ByteArray, String>? {
        val targetName = sortedImageEntryNames(source).getOrNull(index) ?: return null
        return when (source) {
            is ChapterSource.Path -> ZipFile(source.file).use { zip ->
                val entry = zip.getEntry(targetName) ?: return null
                zip.getInputStream(entry).use { it.readBytes() } to mimeTypeFor(entry.name)
            }
            is ChapterSource.Doc -> {
                val stream = openStream(source) ?: return null
                ZipInputStream(stream).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory && entry.name == targetName) {
                            val bytes = zip.readBytes()
                            return bytes to mimeTypeFor(entry.name)
                        }
                        entry = zip.nextEntry
                    }
                }
                null
            }
        }
    }

    private fun isImageEntry(name: String): Boolean {
        val n = name.lowercase()
        return n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".webp")
    }
}

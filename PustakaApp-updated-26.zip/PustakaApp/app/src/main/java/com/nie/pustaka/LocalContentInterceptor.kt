package com.nie.pustaka

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.net.Uri
import java.io.ByteArrayInputStream
import java.io.FileInputStream

/**
 * Pengganti langsung dari:
 *   /media/uploads/<file>   -> host "pustaka.internal", path "/cover/..."
 *   /view_file/<file>       -> host "pustaka.internal", path "/chapter/..."   (mendukung Range, dipakai video)
 *   /cbz_image/<file>/<i>   -> host "pustaka.internal", path "/cbzpage/.../i"
 *   (baru, ganti pdf.js)    -> host "pustaka.internal", path "/pdfpage/.../i"
 *
 * PENTING: ini BUKAN server jaringan. shouldInterceptRequest() adalah callback
 * WebViewClient yang dipanggil in-process setiap kali WebView butuh sebuah
 * resource (mis. <img src>, <video src>) -- tidak ada socket/port yang dibuka.
 *
 * File chapter (pdf/txt/mp4/cbz) dibaca LANGSUNG dari folder yang dipilih user
 * (lihat FileStorageManager.ChapterSource) -- tidak pernah disalin ke storage
 * app, dan tidak pernah dibaca penuh ke memori untuk file besar seperti video;
 * semuanya di-stream, termasuk dukungan Range untuk seek video.
 */
class LocalContentInterceptor(private val storage: FileStorageManager) {

    companion object {
        const val HOST = "pustaka.internal"
        // Semua respons di sini dijawab dari file yang SUDAH tersimpan di device (cover,
        // halaman CBZ/PDF, video) -- WebView tidak boleh menyalin ulang isinya lagi ke
        // cache HTTP disk-nya sendiri (WebView menganggap URL "https://pustaka.internal/.."
        // ini seperti respons jaringan biasa & akan menyimpannya kalau tidak dilarang
        // eksplisit lewat header ini), karena itulah penyebab cache app membengkak
        // makin banyak komik/video yang dibuka.
        private val NO_CACHE_HEADERS = mapOf(
            "Cache-Control" to "no-store, no-cache, must-revalidate",
            "Pragma" to "no-cache"
        )
        fun coverUrl(relativePath: String) = "https://$HOST/cover/${Uri.encode(relativePath)}"
        fun chapterRawUrl(relativePath: String) = "https://$HOST/chapter/${Uri.encode(relativePath)}"
        fun cbzPageUrl(relativePath: String, index: Int) = "https://$HOST/cbzpage/${Uri.encode(relativePath)}/$index"
        fun pdfPageUrl(relativePath: String, index: Int) = "https://$HOST/pdfpage/${Uri.encode(relativePath)}/$index"
    }

    fun intercept(request: WebResourceRequest): WebResourceResponse? {
        val uri = request.url
        if (uri.host != HOST) return null
        val segments = uri.pathSegments
        if (segments.isEmpty()) return notFound()

        return try {
            when (segments[0]) {
                "cover" -> serveCover(segments.drop(1).joinToString("/"))
                "chapter" -> serveChapterRaw(segments.drop(1).joinToString("/"), request)
                "cbzpage" -> serveCbzPage(segments.subList(1, segments.size - 1).joinToString("/"), segments.last().toInt())
                "pdfpage" -> servePdfPage(segments.subList(1, segments.size - 1).joinToString("/"), segments.last().toInt())
                else -> null
            }
        } catch (e: Exception) {
            android.util.Log.w("PustakaIntercept", "gagal melayani ${uri.path}", e)
            WebResourceResponse("text/plain", "utf-8", 500, "Internal Error", emptyMap(), ByteArrayInputStream(ByteArray(0)))
        }
    }

    private fun serveCover(relativePath: String): WebResourceResponse {
        val file = storage.findFile(relativePath, "uploads") ?: return notFound()
        val mime = storage.mimeTypeFor(file.name)
        return WebResourceResponse(mime, null, 200, "OK", NO_CACHE_HEADERS, FileInputStream(file))
    }

    private fun serveCbzPage(relativePath: String, index: Int): WebResourceResponse {
        val source = storage.resolveChapterSource(relativePath) ?: return notFound()
        val (bytes, mime) = storage.cbzPageBytes(source, index) ?: return notFound()
        return WebResourceResponse(mime, null, 200, "OK", NO_CACHE_HEADERS, ByteArrayInputStream(bytes))
    }

    private fun servePdfPage(relativePath: String, index: Int): WebResourceResponse {
        val source = storage.resolveChapterSource(relativePath) ?: return notFound()
        val png = PdfPageRenderer.renderPagePng({ storage.openParcelFileDescriptor(source) }, index) ?: return notFound()
        return WebResourceResponse("image/png", null, 200, "OK", NO_CACHE_HEADERS, ByteArrayInputStream(png))
    }

    /**
     * Melompati persis [n] byte dari [stream]. InputStream.skip() TIDAK dijamin melompati
     * seluruh jumlah yang diminta dalam satu panggilan -- terutama untuk stream dari
     * ParcelFileDescriptor SAF (dipakai di sini), yang kadang berperilaku seperti pipe.
     * Kalau ini tidak di-loop, seek video ke offset yang "gagal di-skip sepenuhnya" akan
     * membuat Range yang disajikan salah (byte-nya meleset dari yang diklaim di header
     * Content-Range) sehingga decoder video menerima data korup -> event 'error' di <video>
     * -> pesan "Gagal Memutar Video" muncul persis saat user melakukan seek/skip.
     */
    private fun skipFully(stream: java.io.InputStream, n: Long) {
        var remaining = n
        while (remaining > 0) {
            val skipped = stream.skip(remaining)
            if (skipped > 0) { remaining -= skipped; continue }
            // skip() balikin 0/negatif (umum utk stream pipe-like): fallback baca & buang.
            val buf = ByteArray(minOf(remaining, 65536L).toInt())
            val read = stream.read(buf, 0, buf.size)
            if (read <= 0) break // EOF asli, tak ada lagi yang bisa dilompati
            remaining -= read
        }
    }

    /** Membatasi InputStream supaya hanya membaca maksimal [limit] byte lalu EOF, sesuai Content-Length yang dijanjikan. */
    private class BoundedInputStream(private val delegate: java.io.InputStream, private var remaining: Long) : java.io.InputStream() {
        override fun read(): Int {
            if (remaining <= 0) return -1
            val b = delegate.read()
            if (b >= 0) remaining--
            return b
        }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (remaining <= 0) return -1
            val toRead = minOf(len.toLong(), remaining).toInt()
            val n = delegate.read(b, off, toRead)
            if (n > 0) remaining -= n
            return n
        }
        override fun close() = delegate.close()
    }

    /**
     * Membuka stream mulai dari byte [start] secara AKURAT.
     * - File biasa (Path): RandomAccessFile.seek() -- langsung lompat, tanpa membaca byte di depannya.
     * - Dokumen SAF (Doc): coba seek lewat FileChannel; kalau fd tidak seekable (pipe), fallback ke skipFully().
     */
    private fun openFrom(source: FileStorageManager.ChapterSource, start: Long): java.io.InputStream? {
        return when (source) {
            is FileStorageManager.ChapterSource.Path -> {
                val raf = java.io.RandomAccessFile(source.file, "r")
                try {
                    raf.seek(start)
                    object : java.io.InputStream() {
                        override fun read(): Int = raf.read()
                        override fun read(b: ByteArray, off: Int, len: Int): Int = raf.read(b, off, len)
                        override fun close() { try { raf.close() } catch (_: Exception) {} }
                    }
                } catch (e: Exception) {
                    try { raf.close() } catch (_: Exception) {}
                    throw e
                }
            }
            is FileStorageManager.ChapterSource.Doc -> {
                val pfd = storage.openParcelFileDescriptor(source)
                if (pfd == null) null else {
                val fis = java.io.FileInputStream(pfd.fileDescriptor)
                val wrapper = object : java.io.InputStream() {
                    override fun read(): Int = fis.read()
                    override fun read(b: ByteArray, off: Int, len: Int): Int = fis.read(b, off, len)
                    override fun close() {
                        try { fis.close() } catch (_: Exception) {}
                        try { pfd.close() } catch (_: Exception) {}
                    }
                }
                try {
                    if (start > 0) {
                        val moved = try { fis.channel.position(start); true } catch (_: Exception) { false }
                        if (!moved) skipFully(wrapper, start)
                    }
                    wrapper
                } catch (e: Exception) {
                    wrapper.close()
                    throw e
                }
                }
            }
        }
    }

    /** Ukuran file; -1 kalau penyedia dokumen tidak mau memberi tahu. */
    private fun lengthOf(source: FileStorageManager.ChapterSource): Long = when (source) {
        is FileStorageManager.ChapterSource.Path -> source.file.length()
        is FileStorageManager.ChapterSource.Doc -> {
            try { storage.openParcelFileDescriptor(source)?.use { it.statSize } ?: -1L } catch (_: Exception) { -1L }
        }
    }

    /** Setara /view_file/<file>: baca mentah + dukung HTTP Range (dibutuhkan <video> agar bisa seek). */
    private fun serveChapterRaw(relativePath: String, request: WebResourceRequest): WebResourceResponse {
        val source = storage.resolveChapterSource(relativePath) ?: return notFound()
        val mime = storage.mimeTypeFor(relativePath)
        val length = lengthOf(source)
        val rangeHeader = request.requestHeaders.entries
            .firstOrNull { it.key.equals("Range", ignoreCase = true) }?.value

        // Ukuran tidak diketahui (sebagian penyedia dokumen): jangan menebak Range/Content-Length
        // yang salah -- sajikan seluruh isi apa adanya tanpa header ukuran.
        if (length <= 0L) {
            val stream = openFrom(source, 0) ?: return notFound()
            return WebResourceResponse(mime, null, 200, "OK", NO_CACHE_HEADERS, stream)
        }

        if (rangeHeader == null) {
            val stream = openFrom(source, 0) ?: return notFound()
            val headers = mapOf("Accept-Ranges" to "bytes", "Content-Length" to length.toString()) + NO_CACHE_HEADERS
            return WebResourceResponse(mime, null, 200, "OK", headers, stream)
        }

        // Format: "bytes=START-END" | "bytes=START-" | "bytes=-SUFFIX"
        val spec = rangeHeader.trim().removePrefix("bytes=").substringBefore(",").split("-")
        val startRaw = spec.getOrNull(0)?.trim().orEmpty()
        val endRaw = spec.getOrNull(1)?.trim().orEmpty()
        val start: Long
        val end: Long
        if (startRaw.isEmpty()) {
            val suffix = endRaw.toLongOrNull() ?: 0L
            start = (length - suffix).coerceAtLeast(0L)
            end = length - 1
        } else {
            start = startRaw.toLongOrNull() ?: 0L
            end = (endRaw.toLongOrNull() ?: (length - 1)).coerceAtMost(length - 1)
        }

        if (start >= length || start > end) {
            val headers = mapOf("Content-Range" to "bytes */$length") + NO_CACHE_HEADERS
            return WebResourceResponse(mime, null, 416, "Range Not Satisfiable", headers, ByteArrayInputStream(ByteArray(0)))
        }

        // openFrom() menutup sendiri fd-nya kalau gagal di tengah jalan (tidak bocor).
        val raw = openFrom(source, start) ?: return notFound()
        val bodyLength = end - start + 1
        val stream = BoundedInputStream(raw, bodyLength)
        val headers = mapOf(
            "Accept-Ranges" to "bytes",
            "Content-Range" to "bytes $start-$end/$length",
            "Content-Length" to bodyLength.toString()
        ) + NO_CACHE_HEADERS
        return WebResourceResponse(mime, null, 206, "Partial Content", headers, stream)
    }

    private fun notFound(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
}

package com.nie.pustaka

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * Pengganti "app.run(host='0.0.0.0', port=5000)" dari Flask.
 * Di sini tidak ada server yang berjalan sama sekali -- WebView memuat halaman
 * dari assets lokal (file:///android_asset/www/index.html) dan JavaScript di
 * halaman itu memanggil langsung method Kotlin lewat window.Android.*
 */
class MainActivity : AppCompatActivity(), WebAppInterface.HostCallbacks {

    private lateinit var webView: WebView
    private lateinit var bridge: WebAppInterface
    private lateinit var storage: FileStorageManager

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        deliverPickedFile(uri, pendingImageRequestId)
        pendingImageRequestId = null
    }

    // Folder tempat SEMUA file chapter (pdf/txt/mp4/cbz) sudah disimpan user sendiri.
    // Dipilih SEKALI lewat System Folder Picker (SAF) -- app hanya membaca dari sini,
    // tidak pernah menyalin isinya ke storage app. Ini yang memperbaiki bug
    // "penyimpanan membengkak" & "layar hitam" saat upload chapter besar.
    private val pickChapterFolderLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        val reqId = pendingChapterFolderRequestId
        pendingChapterFolderRequestId = null
        if (uri == null) {
            webView.post { webView.evaluateJavascript("window.onNativeFolderPicked && window.onNativeFolderPicked('$reqId', false, '')", null) }
            return@registerForActivityResult
        }
        try {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) { /* beberapa penyedia hanya izinkan salah satu flag, tidak fatal */ }
        storage.setChapterFolder(uri)
        val label = storage.getChapterFolderLabel().replace("'", "")
        webView.post { webView.evaluateJavascript("window.onNativeFolderPicked && window.onNativeFolderPicked('$reqId', true, '$label')", null) }
    }

    // Picker file TUNGGAL (SAF) untuk chapter -- pengganti alur "pilih folder lalu
    // jelajahi isinya". User langsung memilih SATU file yang sudah dia simpan sendiri;
    // app hanya menyimpan alamat (content URI) file itu dan membacanya langsung dari
    // sana setiap dibutuhkan -- app TIDAK PERNAH membaca/menjelajahi isi folder mana pun.
    private val pickChapterFileLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        deliverPickedChapterFile(uri, pendingChapterFileRequestId)
        pendingChapterFileRequestId = null
    }

    // Picker BANYAK file sekaligus untuk chapter (multi-select) -- supaya tidak perlu
    // menambah chapter satu per satu.
    private val pickChapterFilesLauncher = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        deliverPickedChapterFiles(uris, pendingChapterFilesRequestId)
        pendingChapterFilesRequestId = null
    }

    // Untuk Android 6.0-9.0 (API 23-28): WRITE_EXTERNAL_STORAGE adalah dangerous permission
    // yang wajib diminta lewat dialog runtime seperti ini (Settings ACTION_MANAGE_..._PERMISSION
    // di bawah hanya berlaku mulai Android 11/API 30 ke atas).
    private val requestStoragePermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            webView.post { webView.evaluateJavascript("window.onAppResumed && window.onAppResumed()", null) }
        }

    // Android 13+: notifikasi butuh izin runtime. Dipakai untuk notifikasi "Server Pustaka aktif"
    // dan "Permintaan izin edit". Kalau ditolak, server tetap jalan (hanya notifikasinya tersembunyi).
    private val requestNotifPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* hasil tidak perlu ditangani */ }

    // ---- Export/Import Backup (data.json + cover gambar dibungkus jadi satu .zip) ----
    // Dipilih lewat System File Picker (SAF) supaya file backup bisa disimpan/dibuka
    // dari lokasi mana pun (termasuk Google Drive dsb lewat provider lain), tanpa app
    // butuh izin penyimpanan tambahan apa pun untuk fitur ini.
    private val exportBackupLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val reqId = pendingBackupRequestId
        pendingBackupRequestId = null
        if (uri == null || reqId == null) {
            webView.post { webView.evaluateJavascript("window.onBackupExported && window.onBackupExported('$reqId', false)", null) }
            return@registerForActivityResult
        }
        Thread {
            val ok = backupManager.exportTo(uri)
            webView.post { webView.evaluateJavascript("window.onBackupExported && window.onBackupExported('$reqId', $ok)", null) }
        }.start()
    }

    private val importBackupLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val reqId = pendingBackupRequestId
        pendingBackupRequestId = null
        if (uri == null || reqId == null) {
            webView.post { webView.evaluateJavascript("window.onBackupImported && window.onBackupImported('$reqId', false)", null) }
            return@registerForActivityResult
        }
        Thread {
            val ok = backupManager.importFrom(uri)
            webView.post { webView.evaluateJavascript("window.onBackupImported && window.onBackupImported('$reqId', $ok)", null) }
        }.start()
    }

    private var pendingImageRequestId: String? = null
    private var pendingChapterFolderRequestId: String? = null
    private var pendingChapterFileRequestId: String? = null
    private var pendingChapterFilesRequestId: String? = null
    private var pendingBackupRequestId: String? = null
    private var isImmersive = false
    private var isLandscapeLocked = false
    private var isPortraitForced = false
    private lateinit var backupManager: BackupManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Instance dibagi dengan ShareServer (browser pengguna lain) -> lewat Graph.
        val dbHelper = Graph.db(this)
        storage = Graph.storage(this)
        storage.ensureDefaultFolders()
        backupManager = BackupManager(this, dbHelper, storage)
        bridge = WebAppInterface(dbHelper, storage, this)

        val interceptor = LocalContentInterceptor(storage)

        webView = findViewById(R.id.webview)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true // content:// (SAF) untuk <video> saat path asli tak tersedia
            // Semua gambar/halaman komik/video dijawab LocalContentInterceptor langsung
            // dari file lokal yang sudah tersimpan di device (bukan jaringan sungguhan),
            // jadi tidak ada gunanya WebView MENYALIN ULANG isinya lagi ke cache disk-nya
            // sendiri -- itu penyebab utama "penyimpanan/cache app membengkak" seiring
            // makin banyak cover/halaman komik/video yang dibuka. LOAD_NO_CACHE dipasang
            // di sini, DITAMBAH header "Cache-Control: no-store" di setiap respons
            // LocalContentInterceptor (lapisan kedua supaya WebView benar-benar tidak
            // menyimpan salinannya sama sekali, bukan cuma "tidak pakai cache lama").
            cacheMode = WebSettings.LOAD_NO_CACHE
            mediaPlaybackRequiresUserGesture = false // supaya <video autoplay> jalan sama seperti versi Flask
        }
        // Bersihkan sisa cache WebView yang mungkin sudah lanjur menumpuk dari sebelum
        // perbaikan ini dipasang (mis. dari APK versi lama) -- sekali saat app dibuka.
        webView.clearCache(true)
        webView.addJavascriptInterface(bridge, "Android")
        webView.webViewClient = object : android.webkit.WebViewClient() {
            // Ini pengganti "server": setiap <img>/<video> yang menunjuk ke
            // https://pustaka.internal/... dicegat & dijawab langsung dari
            // penyimpanan lokal lewat LocalContentInterceptor -- tidak ada
            // request jaringan sungguhan yang pernah terjadi.
            override fun shouldInterceptRequest(
                view: WebView, request: android.webkit.WebResourceRequest
            ): android.webkit.WebResourceResponse? {
                return interceptor.intercept(request) ?: super.shouldInterceptRequest(view, request)
            }
        }
        // TANPA WebChromeClient, WebView Android SECARA DIAM-DIAM mengabaikan
        // window.alert() (tidak menampilkan apa pun) dan otomatis membatalkan
        // window.confirm() (selalu balikan `false` tanpa pernah bertanya ke user)
        // -- berbeda dari browser biasa (Chrome/desktop) tempat app.js ini awalnya
        // diuji, di mana keduanya tampil sebagai dialog normal. Akibatnya semua
        // tombol "Hapus" (kategori, koleksi, chapter, bookmark) dan semua pesan
        // validasi/notifikasi lewat alert() di app.js akan terlihat seperti tidak
        // berbuat apa-apa saat ditekan di dalam app native. Di sinilah keduanya
        // diberi implementasi native (AlertDialog) agar benar-benar berfungsi
        // sama seperti di browser/versi Flask.
        webView.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setOnCancelListener { result.confirm() }
                    .setCancelable(true)
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView, url: String, message: String, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setNegativeButton("Batal") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .setCancelable(true)
                    .show()
                return true
            }
        }
        webView.loadUrl("file:///android_asset/www/index.html")
    }

    override fun onResume() {
        super.onResume()
        // Setelah user kembali dari halaman Settings Android (mis. setelah memberi izin
        // "Kelola semua file" lewat requestManageStoragePermission()), beri tahu JS agar
        // status/peringatan terkait bisa diperbarui otomatis tanpa perlu navigasi manual.
        webView.post {
            webView.evaluateJavascript("window.onAppResumed && window.onAppResumed()", null)
            // Pemutar video: pulihkan elemen <video> yang mungkin rusak selama app di background.
            webView.evaluateJavascript("window.onVideoAppResumed && window.onVideoAppResumed()", null)
        }
        // Ada pengguna lain yang minta izin edit? Tampilkan dialog persetujuan.
        ShareHost.uiListener = { runOnUiThread { showNextEditRequest() } }
        showNextEditRequest()
    }

    override fun onPause() {
        ShareHost.uiListener = null
        // Pemutar video: jeda & ingat posisi terakhir sebelum app ke background.
        webView.evaluateJavascript("window.onVideoAppPaused && window.onVideoAppPaused()", null)
        super.onPause()
    }

    override fun onBackPressed() {
        // Kalau lagi terkunci landscape (dari player video) dan user menekan tombol
        // kembali, lepaskan dulu kuncian rotasinya supaya layar lain di app tidak
        // ikut ke-lock landscape.
        if (isLandscapeLocked || isImmersive) {
            isLandscapeLocked = false
            isPortraitForced = false
            isImmersive = false
            applyImmersiveMode()
            requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    // ---------------- HostCallbacks (dipanggil dari WebAppInterface) ----------------

    override fun pickImage(requestId: String) {
        pendingImageRequestId = requestId
        pickImageLauncher.launch("image/*")
    }

    override fun pickChapterSourceFolder(requestId: String) {
        pendingChapterFolderRequestId = requestId
        pickChapterFolderLauncher.launch(null)
    }

    override fun pickChapterFile(requestId: String) {
        pendingChapterFileRequestId = requestId
        // "*/*" dipakai karena CBZ tidak punya MIME type baku yang konsisten antar
        // penyedia dokumen -- validasi ekstensi (pdf/txt/mp4/cbz) dilakukan sesudahnya.
        pickChapterFileLauncher.launch(arrayOf("*/*"))
    }

    override fun pickChapterFiles(requestId: String) {
        pendingChapterFilesRequestId = requestId
        pickChapterFilesLauncher.launch(arrayOf("*/*"))
    }

    override fun openExternalFile(pathOrUri: String, isContentUri: Boolean, mime: String) {
        val uri: Uri = if (isContentUri) {
            Uri.parse(pathOrUri)
        } else {
            FileProvider.getUriForFile(this, "com.nie.pustaka.fileprovider", java.io.File(pathOrUri))
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent.createChooser(intent, "Buka dengan"))
        } catch (_: Exception) {
            webView.post { webView.evaluateJavascript("alert('Tidak ada aplikasi yang bisa membuka file ini.')", null) }
        }
    }

    override fun requestManageStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Android 11+ : izin "Kelola semua file" hanya bisa diberikan lewat halaman Settings.
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            // Android 7-9 (API 24-28, minSdk proyek ini 24): WRITE_EXTERNAL_STORAGE
            // diminta lewat dialog izin runtime biasa, BUKAN lewat halaman Settings.
            requestStoragePermissionLauncher.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
    }

    /**
     * "Toggle Layar Penuh" versi Flask memanggil Fullscreen API browser biasa
     * (`requestFullscreen()`), yang di BROWSER SUNGGUHAN memang menyembunyikan
     * seluruh chrome (address bar, dst). Tapi di dalam WebView milik app native,
     * API JS itu TIDAK punya akses untuk menyembunyikan status bar/navigation
     * bar Android -- makanya tombolnya "jalan" tapi layar tidak benar-benar
     * penuh. Di sini diganti perintah native Android (immersive mode) supaya
     * hasilnya benar-benar layar penuh, sama seperti yang dimaksud aslinya.
     */
    override fun toggleFullscreen(): Boolean {
        isImmersive = !isImmersive
        // PENTING: method @JavascriptInterface (dipanggil dari WebView lewat Android.toggleFullscreen())
        // dieksekusi Android di THREAD LATAR BELAKANG WebView, BUKAN thread UI -- ini yang
        // membuat tombol "Toggle Layar Penuh" sebelumnya terkesan "tidak berfungsi": kode
        // yang mengubah systemBars (status bar & navigation bar) butuh berjalan di thread UI,
        // kalau tidak, perubahannya bisa gagal diterapkan tanpa app ter-crash sama sekali
        // (gagal diam-diam). runOnUiThread di sini yang memperbaikinya.
        runOnUiThread { applyImmersiveMode() }
        return isImmersive
    }

    override fun exitFullscreen() {
        // Dipanggil router saat pindah ke halaman non-reader. Selain immersive mode,
        // kuncian landscape dari player video juga harus dilepas, kalau tidak layar
        // daftar/detail ikut nyangkut landscape setelah keluar lewat tombol "Kembali" di app.
        if (!isImmersive && !isLandscapeLocked) return
        isImmersive = false
        isLandscapeLocked = false
        isPortraitForced = false
        runOnUiThread {
            applyImmersiveMode()
            requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    /**
     * Layar penuh untuk player video: sembunyikan status bar + navigation bar DAN kunci
     * landscape dalam satu perintah, lalu kembalikan ke normal saat keluar. Sengaja
     * menerima nilai eksplisit (bukan toggle) supaya status di JS dan native tidak
     * pernah tidak sinkron. Wajib runOnUiThread karena method @JavascriptInterface
     * berjalan di thread latar WebView.
     */
    override fun setVideoFullscreen(enabled: Boolean) {
        isImmersive = enabled
        isLandscapeLocked = enabled
        isPortraitForced = false
        runOnUiThread {
            applyImmersiveMode()
            requestedOrientation = if (enabled)
                android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else
                android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    /** Cegah layar mati sendiri selama video diputar (dilepas saat jeda / selesai / keluar dari player). */
    override fun keepScreenOn(enabled: Boolean) {
        runOnUiThread {
            if (enabled) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    /**
     * Rotasi layar dari tombol "Putar Layar" di player video. JS sempat mencoba
     * screen.orientation.lock() bawaan browser, tapi API itu butuh Fullscreen API
     * (element.requestFullscreen()) aktif dulu -- yang TIDAK dipakai di sini (kita
     * pakai immersive mode native Android, bukan Fullscreen API web) -- sehingga
     * panggilannya selalu ditolak diam-diam dan layar tidak pernah benar-benar
     * berputar. Diganti perintah native: langsung mengatur requestedOrientation
     * Activity, yang selalu berhasil apa pun mode fullscreen JS-nya.
     * Sama seperti toggleFullscreen(): method @JavascriptInterface dieksekusi di
     * thread latar WebView, jadi wajib runOnUiThread supaya benar-benar diterapkan.
     */
    override fun toggleOrientation(): Boolean {
        // Bolak-balik landscape <-> portrait secara eksplisit (tidak bergantung pada
        // pengaturan auto-rotate perangkat). Tetap dianggap "terkunci" supaya tombol
        // kembali / keluar dari player melepas kuncian lewat onBackPressed/exitFullscreen.
        isPortraitForced = !isPortraitForced
        isLandscapeLocked = true
        runOnUiThread {
            requestedOrientation = if (isPortraitForced)
                android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            else
                android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        return !isPortraitForced
    }

    // ---------------- Server berbagi ----------------

    override fun startShareServer(): String {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            // @JavascriptInterface berjalan di thread latar WebView -> launcher wajib di thread UI.
            runOnUiThread { requestNotifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
        }
        ShareHost.start(this)
            ?: return org.json.JSONObject()
                .put("error", "Gagal membuka port server (port 8080-8090 sedang dipakai aplikasi lain).")
                .toString()
        return ShareHost.statusJson()
    }

    override fun stopShareServer() {
        ShareHost.stop(this)
    }

    override fun shareText(text: String) {
        // @JavascriptInterface berjalan di thread latar WebView -> startActivity dari thread UI.
        runOnUiThread {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            try {
                startActivity(Intent.createChooser(send, "Bagikan link Pustaka"))
            } catch (_: Exception) { /* tidak ada aplikasi pembagi -- abaikan */ }
        }
    }

    private var editDialogShowing = false

    /** Dialog persetujuan satu per satu untuk klien yang minta izin edit. */
    private fun showNextEditRequest() {
        if (editDialogShowing || isFinishing) return
        val server = ShareHost.server ?: return
        val c = server.pendingClients().firstOrNull() ?: return
        editDialogShowing = true
        AlertDialog.Builder(this)
            .setTitle("Permintaan izin edit")
            .setMessage("\"${c.name}\" (${c.ip}) ingin mengedit koleksi di Pustaka.\n\nIzinkan?")
            .setCancelable(false)
            .setPositiveButton("Izinkan") { _, _ -> server.setEdit(c.id, true) }
            .setNegativeButton("Tolak") { _, _ -> server.setEdit(c.id, false) }
            .setOnDismissListener {
                editDialogShowing = false
                showNextEditRequest()
            }
            .show()
    }

    override fun exportBackup(requestId: String) {
        pendingBackupRequestId = requestId
        val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmm", java.util.Locale.getDefault()).format(java.util.Date())
        exportBackupLauncher.launch("pustaka_backup_$stamp.zip")
    }

    override fun importBackup(requestId: String) {
        pendingBackupRequestId = requestId
        importBackupLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*"))
    }

    private fun applyImmersiveMode() {
        WindowCompat.setDecorFitsSystemWindows(window, !isImmersive)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (isImmersive) {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    /** Baca file yang dipilih user lalu kirim balik ke JS sebagai base64 (menggantikan multipart upload ke Flask). */
    private fun deliverPickedFile(uri: Uri?, requestId: String?) {
        if (uri == null || requestId == null) {
            webView.post { webView.evaluateJavascript("window.onNativeFilePicked && window.onNativeFilePicked('$requestId', null, null)", null) }
            return
        }
        contentResolver.openInputStream(uri)?.use { input ->
            val bytes = input.readBytes()
            val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
            val name = queryFileName(uri) ?: "file"
            webView.post {
                webView.evaluateJavascript(
                    "window.onNativeFilePicked && window.onNativeFilePicked('$requestId', '${b64}', '${name.replace("'", "")}')",
                    null
                )
            }
        }
    }

    /**
     * Kirim balik ALAMAT (content URI) file chapter yang dipilih user ke JS -- BUKAN isi
     * filenya. Berbeda dari deliverPickedFile() (cover), file chapter tidak pernah dibaca
     * ke memori/di-base64-kan di sini; app hanya menyimpan referensi ini lalu membaca
     * langsung dari alamatnya setiap dibutuhkan (lihat FileStorageManager.resolveChapterSource).
     */
    private fun deliverPickedChapterFile(uri: Uri?, requestId: String?) {
        if (uri == null || requestId == null) {
            webView.post { webView.evaluateJavascript("window.onNativeChapterFilePicked && window.onNativeChapterFilePicked('$requestId', false, '', '')", null) }
            return
        }
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
            // Sebagian penyedia dokumen tidak mendukung izin persisten -- file tetap
            // bisa dibaca selama proses app ini berjalan meski begitu.
        }
        val name = queryFileName(uri) ?: uri.lastPathSegment ?: "file"
        // Kalau app sudah punya izin "Kelola Semua File" DAN file ini bisa dipetakan ke
        // path asli, simpan PATH MENTAHNYA -- dibaca selamanya lewat java.io.File biasa,
        // persis seperti folder "static" Flask, jauh lebih andal untuk file besar (100MB+)
        // daripada content URI (yang pada sebagian penyedia dokumen cuma pipe berurutan).
        val realPath = storage.realAbsolutePathFor(uri)
        val address = if (realPath != null && storage.hasManageStoragePermission()) realPath else uri.toString()
        // JSONObject.quote() menghasilkan literal string JS yang aman (apostrof, kutip, backslash
        // di nama/path file tidak merusak path seperti sebelumnya, saat apostrof dibuang begitu saja).
        val addressJs = org.json.JSONObject.quote(address)
        val nameJs = org.json.JSONObject.quote(name)
        webView.post {
            webView.evaluateJavascript(
                "window.onNativeChapterFilePicked && window.onNativeChapterFilePicked('$requestId', true, $addressJs, $nameJs)",
                null
            )
        }
    }

    /** Kirim balik daftar {uri, name} semua file yang dipilih (alamat saja, bukan isi file). */
    private fun deliverPickedChapterFiles(uris: List<Uri>?, requestId: String?) {
        if (uris.isNullOrEmpty() || requestId == null) {
            webView.post { webView.evaluateJavascript("window.onNativeChapterFilesPicked && window.onNativeChapterFilesPicked('$requestId', false, '[]')", null) }
            return
        }
        val arr = org.json.JSONArray()
        for (uri in uris) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { /* tidak fatal, sama seperti picker tunggal */ }
            val name = queryFileName(uri) ?: uri.lastPathSegment ?: "file"
            val realPath = storage.realAbsolutePathFor(uri)
            val address = if (realPath != null && storage.hasManageStoragePermission()) realPath else uri.toString()
            arr.put(org.json.JSONObject().put("uri", address).put("name", name))
        }
        val jsonJs = org.json.JSONObject.quote(arr.toString())
        webView.post {
            webView.evaluateJavascript(
                "window.onNativeChapterFilesPicked && window.onNativeChapterFilesPicked('$requestId', true, $jsonJs)",
                null
            )
        }
    }

    private fun queryFileName(uri: Uri): String? {
        var name: String? = null
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIndex >= 0) name = cursor.getString(nameIndex)
        }
        return name
    }
}

package com.nie.pustaka

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Pengganti fitur "Import/Export data" di tombol pengaturan aplikasi.
 *
 * Backup dibungkus jadi SATU file .zip berisi:
 *  - data.json  : seluruh baris tabel collection/categories/collection_categories/
 *                 chapter_list/bookmarks (metadata koleksi & daftar isi)
 *  - images/... : semua gambar cover yang tersimpan di folder "uploads" internal app
 *
 * CATATAN: referensi file chapter (pdf/txt/mp4/cbz) TIDAK disalin ke dalam backup --
 * app ini sejak awal tidak pernah menyalin file chapter ke storage sendiri (lihat
 * FileStorageManager), jadi backup hanya menyimpan ALAMAT-nya. Kalau backup dipulihkan
 * di device lain, chapter yang alamatnya berupa path/izin lokal ke device asal perlu
 * dipilih ulang oleh user lewat "+ TAMBAH" di halaman detail masing-masing koleksi.
 */
class BackupManager(
    private val context: Context,
    private val db: DatabaseHelper,
    private val storage: FileStorageManager
) {

    fun exportTo(uri: Uri): Boolean {
        return try {
            context.contentResolver.openOutputStream(uri)?.use { out ->
                ZipOutputStream(out).use { zip ->
                    val data = JSONObject()
                    data.put("schema_version", 1)
                    data.put("collection", tableToJsonArray("collection"))
                    data.put("categories", tableToJsonArray("categories"))
                    data.put("collection_categories", tableToJsonArray("collection_categories"))
                    data.put("chapter_list", tableToJsonArray("chapter_list"))
                    data.put("bookmarks", tableToJsonArray("bookmarks"))

                    zip.putNextEntry(ZipEntry("data.json"))
                    zip.write(data.toString().toByteArray(Charsets.UTF_8))
                    zip.closeEntry()

                    val seen = mutableSetOf<String>()
                    db.readableDatabase.rawQuery(
                        "SELECT image_path FROM collection WHERE image_path IS NOT NULL AND image_path != ''", null
                    ).use { c ->
                        while (c.moveToNext()) {
                            val path = c.getString(0)
                            if (path.isNullOrEmpty() || !seen.add(path)) continue
                            val file = storage.findFile(path, "uploads") ?: continue
                            zip.putNextEntry(ZipEntry("images/$path"))
                            file.inputStream().use { it.copyTo(zip) }
                            zip.closeEntry()
                        }
                    }
                }
            } ?: return false
            true
        } catch (_: Exception) {
            false
        }
    }

    fun importFrom(uri: Uri): Boolean {
        return try {
            var dataJson: JSONObject? = null
            val images = mutableMapOf<String, ByteArray>()
            context.contentResolver.openInputStream(uri)?.use { input ->
                ZipInputStream(input).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        val name = entry.name
                        when {
                            name == "data.json" -> dataJson = JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                            name.startsWith("images/") -> images[name.removePrefix("images/")] = zip.readBytes()
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            } ?: return false
            val data = dataJson ?: return false
            restoreData(data, images)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun restoreData(data: JSONObject, images: Map<String, ByteArray>) {
        val wdb = db.writableDatabase
        wdb.beginTransaction()
        try {
            // Kategori: cocokkan berdasarkan nama (kolom "name" UNIQUE) supaya import
            // berulang/dari device lain tidak membuat playlist duplikat.
            val catIdMap = mutableMapOf<Long, Long>()
            val cats = data.optJSONArray("categories") ?: JSONArray()
            for (i in 0 until cats.length()) {
                val c = cats.getJSONObject(i)
                val oldId = c.optLong("id", -1)
                val name = c.optString("name")
                if (name.isEmpty()) continue
                var newId = -1L
                wdb.rawQuery("SELECT id FROM categories WHERE name = ?", arrayOf(name)).use { cur ->
                    if (cur.moveToFirst()) newId = cur.getLong(0)
                }
                if (newId == -1L) newId = wdb.insert("categories", null, ContentValues().apply { put("name", name) })
                if (oldId != -1L) catIdMap[oldId] = newId
            }

            // Koleksi: selalu dibuat sebagai entri BARU (backup adalah data tambahan, bukan
            // pengganti isi yang sudah ada) -- gambar cover ditulis ulang lewat FileStorageManager
            // memakai nama file yang sama seperti di backup.
            val collIdMap = mutableMapOf<Long, Long>()
            val colls = data.optJSONArray("collection") ?: JSONArray()
            for (i in 0 until colls.length()) {
                val item = colls.getJSONObject(i)
                val oldId = item.optLong("id", -1)
                var newImagePath = ""
                val imgPath = item.optString("image_path", "")
                if (imgPath.isNotEmpty()) {
                    images[imgPath]?.let { bytes ->
                        newImagePath = storage.saveFile(bytes, "internal", "uploads", imgPath)
                    }
                }
                val cv = ContentValues().apply {
                    put("title", item.optString("title"))
                    put("type", item.optString("type"))
                    put("genre", item.optString("genre"))
                    put("status", item.optString("status"))
                    put("chapters", item.optString("chapters", ""))
                    put("episodes", item.optString("episodes", ""))
                    put("description", item.optString("description"))
                    put("image_path", newImagePath)
                    put("is_favorite", item.optInt("is_favorite", 0))
                }
                val newId = wdb.insert("collection", null, cv)
                if (oldId != -1L) collIdMap[oldId] = newId
            }

            val ccs = data.optJSONArray("collection_categories") ?: JSONArray()
            for (i in 0 until ccs.length()) {
                val cc = ccs.getJSONObject(i)
                val newColl = collIdMap[cc.optLong("collection_id", -1)] ?: continue
                val newCat = catIdMap[cc.optLong("category_id", -1)] ?: continue
                wdb.insert("collection_categories", null, ContentValues().apply {
                    put("collection_id", newColl); put("category_id", newCat)
                })
            }

            val chapIdMap = mutableMapOf<Long, Long>()
            val chaps = data.optJSONArray("chapter_list") ?: JSONArray()
            for (i in 0 until chaps.length()) {
                val ch = chaps.getJSONObject(i)
                val newColl = collIdMap[ch.optLong("collection_id", -1)] ?: continue
                val oldId = ch.optLong("id", -1)
                val cv = ContentValues().apply {
                    put("collection_id", newColl)
                    put("chapter_name", ch.optString("chapter_name"))
                    put("file_name", ch.optString("file_name"))
                    put("order_index", ch.optInt("order_index", 0))
                    put("upload_date", ch.optString("upload_date", ""))
                }
                val newId = wdb.insert("chapter_list", null, cv)
                if (oldId != -1L) chapIdMap[oldId] = newId
            }

            val bms = data.optJSONArray("bookmarks") ?: JSONArray()
            for (i in 0 until bms.length()) {
                val bm = bms.getJSONObject(i)
                val newColl = collIdMap[bm.optLong("collection_id", -1)] ?: continue
                val newChap = chapIdMap[bm.optLong("chapter_id", -1)] ?: continue
                wdb.insert("bookmarks", null, ContentValues().apply {
                    put("collection_id", newColl)
                    put("chapter_id", newChap)
                    put("page_index", bm.optInt("page_index", 0))
                })
            }

            wdb.setTransactionSuccessful()
        } finally {
            wdb.endTransaction()
        }
    }

    private fun tableToJsonArray(table: String): JSONArray {
        val out = JSONArray()
        db.readableDatabase.rawQuery("SELECT * FROM $table", null).use { c ->
            while (c.moveToNext()) out.put(rowToJson(c))
        }
        return out
    }

    private fun rowToJson(c: Cursor): JSONObject {
        val obj = JSONObject()
        for (i in 0 until c.columnCount) {
            val name = c.getColumnName(i)
            when (c.getType(i)) {
                Cursor.FIELD_TYPE_INTEGER -> obj.put(name, c.getLong(i))
                Cursor.FIELD_TYPE_FLOAT -> obj.put(name, c.getDouble(i))
                Cursor.FIELD_TYPE_NULL -> obj.put(name, JSONObject.NULL)
                else -> obj.put(name, c.getString(i))
            }
        }
        return obj
    }
}

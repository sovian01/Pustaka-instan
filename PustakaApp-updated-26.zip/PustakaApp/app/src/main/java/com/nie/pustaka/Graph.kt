package com.nie.pustaka

import android.content.Context

/**
 * Satu-satunya instance DatabaseHelper & FileStorageManager untuk seluruh proses app.
 * Dipakai bersama oleh MainActivity (WebView di HP) dan ShareServer (browser pengguna lain),
 * supaya keduanya membaca/menulis database yang SAMA lewat koneksi yang sama.
 */
object Graph {
    @Volatile private var dbInstance: DatabaseHelper? = null
    @Volatile private var storageInstance: FileStorageManager? = null

    fun db(ctx: Context): DatabaseHelper =
        dbInstance ?: synchronized(this) {
            dbInstance ?: DatabaseHelper(ctx.applicationContext).also { dbInstance = it }
        }

    fun storage(ctx: Context): FileStorageManager =
        storageInstance ?: synchronized(this) {
            storageInstance ?: FileStorageManager(ctx.applicationContext).also { storageInstance = it }
        }
}

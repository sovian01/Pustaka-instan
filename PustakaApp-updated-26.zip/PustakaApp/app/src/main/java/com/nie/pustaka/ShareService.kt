package com.nie.pustaka

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

/**
 * Pengendali tunggal server berbagi. Dipegang sebagai singleton supaya tetap hidup
 * selama proses app hidup (ditopang ShareService sebagai foreground service, jadi
 * server tidak mati saat app ditutup ke background / layar mati).
 */
object ShareHost {

    @Volatile var server: ShareServer? = null

    /** Diisi MainActivity saat tampil di layar (untuk memunculkan dialog izin edit langsung). */
    @Volatile var uiListener: (() -> Unit)? = null

    /** Bridge "kosong" untuk server: aksi yang butuh Activity (picker, fullscreen, dst) tidak dipakai klien remote. */
    private object NoopHost : WebAppInterface.HostCallbacks {
        override fun pickImage(requestId: String) {}
        override fun pickChapterSourceFolder(requestId: String) {}
        override fun pickChapterFile(requestId: String) {}
        override fun pickChapterFiles(requestId: String) {}
        override fun openExternalFile(pathOrUri: String, isContentUri: Boolean, mime: String) {}
        override fun requestManageStoragePermission() {}
        override fun toggleFullscreen(): Boolean = false
        override fun exitFullscreen() {}
        override fun toggleOrientation(): Boolean = false
        override fun setVideoFullscreen(enabled: Boolean) {}
        override fun keepScreenOn(enabled: Boolean) {}
        override fun exportBackup(requestId: String) {}
        override fun importBackup(requestId: String) {}
        override fun startShareServer(): String = "{}"
        override fun stopShareServer() {}
        override fun shareText(text: String) {}
    }

    /** Nyalakan server; null kalau gagal membuka port. */
    fun start(ctx: Context): ShareServer? {
        val app = ctx.applicationContext
        synchronized(this) {
            server?.let { if (it.isRunning) return it }
            val db = Graph.db(app)
            val storage = Graph.storage(app)
            val bridge = WebAppInterface(db, storage, NoopHost)
            val s = ShareServer(app, db, bridge, LocalContentInterceptor(storage)) { storage.getSharePin() }
            s.onEditRequested = { c -> onEditRequested(app, c) }
            if (!s.start(8080)) return null
            server = s
        }
        ContextCompat.startForegroundService(app, Intent(app, ShareService::class.java))
        return server
    }

    fun stop(ctx: Context) {
        val app = ctx.applicationContext
        stopServerOnly()
        app.stopService(Intent(app, ShareService::class.java))
    }

    fun stopServerOnly() {
        synchronized(this) {
            server?.stop()
            server = null
        }
    }

    private fun onEditRequested(app: Context, c: ShareServer.Client) {
        val l = uiListener
        if (l != null) l() else ShareService.notifyEditRequest(app, c)
    }

    fun statusJson(): String {
        val s = server
        val o = JSONObject()
        if (s == null || !s.isRunning) return o.put("running", false).toString()
        val now = System.currentTimeMillis()
        val arr = JSONArray()
        for (c in s.clientsSnapshot()) {
            arr.put(
                JSONObject()
                    .put("id", c.id).put("name", c.name).put("ip", c.ip)
                    .put("can_edit", c.canEdit).put("pending", c.pending)
                    .put("idle_s", (now - c.lastSeen) / 1000)
            )
        }
        o.put("running", true).put("port", s.port).put("locked", s.pinRequired())
        o.put("urls", JSONArray(s.urls()))
        o.put("clients", arr)
        return o.toString()
    }
}

/**
 * Foreground service: hanya "penopang" agar Android tidak mematikan proses saat server aktif.
 * Server sendiri hidup di ShareHost.
 */
class ShareService : Service() {

    companion object {
        const val CHANNEL_ID = "pustaka_share"
        const val CHANNEL_REQ = "pustaka_share_req"
        const val NOTIF_ID = 1001
        const val ACTION_STOP = "com.nie.pustaka.action.STOP_SHARE"

        fun ensureChannels(ctx: Context) {
            if (Build.VERSION.SDK_INT < 26) return
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Server Pustaka", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_REQ, "Permintaan izin edit", NotificationManager.IMPORTANCE_HIGH)
            )
        }

        /** Dipakai saat ada yang minta izin edit tapi app tidak sedang di layar. */
        fun notifyEditRequest(ctx: Context, c: ShareServer.Client) {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) return
            ensureChannels(ctx)
            val open = PendingIntent.getActivity(
                ctx, 0,
                Intent(ctx, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(ctx, CHANNEL_REQ)
                .setSmallIcon(android.R.drawable.ic_menu_share)
                .setContentTitle("Permintaan izin edit")
                .setContentText("${c.name} (${c.ip}) ingin mengedit Pustaka. Ketuk untuk menjawab.")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            try {
                NotificationManagerCompat.from(ctx).notify(2000 + (c.id.hashCode() and 0xfff), n)
            } catch (_: SecurityException) {
            }
        }
    }

    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            ShareHost.stop(this)
            return START_NOT_STICKY
        }
        ensureChannels(this)
        val server = ShareHost.server
        if (server == null || !server.isRunning) {
            // Proses dibuat ulang tanpa server: tetap wajib startForeground() sebelum berhenti.
            startForegroundCompat(buildNotification("Server tidak aktif"))
            stopSelf()
            return START_NOT_STICKY
        }
        val urls = server.urls()
        startForegroundCompat(buildNotification(if (urls.isEmpty()) "Port ${server.port}" else urls.joinToString("  ")))
        acquireLocks()
        return START_NOT_STICKY
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ShareService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentTitle("Server Pustaka aktif")
            .setContentText(text)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(open)
            .addAction(0, "Matikan", stop)
            .build()
    }

    private fun startForegroundCompat(n: Notification) {
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        try {
            if (wifiLock == null) {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "pustaka:share").apply {
                    setReferenceCounted(false)
                    acquire()
                }
            }
            if (wakeLock == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "pustaka:share").apply {
                    setReferenceCounted(false)
                    acquire()
                }
            }
        } catch (_: Exception) {
            // lock gagal bukan masalah fatal -- server tetap jalan selama layar menyala
        }
    }

    override fun onDestroy() {
        try { wifiLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wifiLock = null
        wakeLock = null
        // Service mati (mis. dari tombol "Matikan") -> server ikut berhenti.
        ShareHost.stopServerOnly()
        super.onDestroy()
    }
}

// ============================================================================
// Pengganti seluruh render_template_string() Flask.
// Semua data lewat window.Android.*  (lihat WebAppInterface.kt) -- tanpa fetch(),
// tanpa endpoint HTTP, tanpa server. Router SPA sederhana berbasis location.hash.
// ============================================================================

const app = document.getElementById('app');

function h(strings, ...values) { // helper template literal biasa, cuma alias
  return strings.reduce((acc, s, i) => acc + s + (values[i] ?? ''), '');
}
function esc(s) {
  if (s === null || s === undefined) return '';
  return String(s).replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}
// Format detik -> "m:ss" / "h:mm:ss" -- dipakai di pemutar video & daftar penanda video,
// supaya penanda posisi tonton tampil sebagai waktu (mis. "12:34"), bukan nomor halaman.
function fmtTime(sec) {
  if (!isFinite(sec) || sec < 0) sec = 0;
  sec = Math.floor(sec);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const mm = h > 0 ? String(m).padStart(2, '0') : String(m);
  const ss = String(s).padStart(2, '0');
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}
// Placeholder transparan -- menghindari <img src=""> yang di WebView bisa memicu
// permintaan ulang ke halaman saat ini (bug rendering yang tidak ada di browser desktop).
const BLANK_IMG = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg'%3E%3C/svg%3E";

// ---- Pembungkus pemilihan gambar cover native (menggantikan <input type=file> browser) ----
// Cover berukuran kecil, jadi tetap dikirim sebagai base64 seperti semula.
let fileRequestSeq = 0;
window.onNativeFilePicked = null;
function pickNativeImage() {
  return new Promise((resolve) => {
    const reqId = 'req' + (fileRequestSeq++);
    window.onNativeFilePicked = (id, base64, filename) => {
      if (id !== reqId) return;
      resolve(base64 ? { base64, filename } : null);
    };
    Android.pickImage(reqId);
  });
}

// ---- Pembungkus pemilihan Folder Chapter (SAF System Folder Picker) ----
// Chapter (pdf/txt/mp4/cbz) TIDAK PERNAH dibaca penuh ke memori/di-base64-kan di sini --
// hanya referensi foldernya yang diminta, itu sebabnya upload chapter besar tidak lagi
// membuat penyimpanan app membengkak atau membuat layar hitam.
let folderRequestSeq = 0;
window.onNativeFolderPicked = null;
function pickChapterFolder() {
  return new Promise((resolve) => {
    const reqId = 'freq' + (folderRequestSeq++);
    window.onNativeFolderPicked = (id, ok, path) => {
      if (id !== reqId) return;
      resolve(ok ? { path } : null);
    };
    Android.pickChapterSourceFolder(reqId);
  });
}

// ---- Pembungkus pemilihan SATU file chapter (SAF System File Picker) ----
// Tidak ada folder yang dijelajahi/dibaca isinya di sini -- user langsung memilih
// SATU file lewat picker bawaan Android, dan app hanya menerima ALAMAT (content URI)
// file itu. Chapter dibaca langsung dari alamat itu setiap dibutuhkan.
let chapterFileRequestSeq = 0;
window.onNativeChapterFilePicked = null;
function pickChapterFile() {
  return new Promise((resolve) => {
    const reqId = 'cfreq' + (chapterFileRequestSeq++);
    window.onNativeChapterFilePicked = (id, ok, uri, name) => {
      if (id !== reqId) return;
      resolve(ok ? { uri, name } : null);
    };
    Android.pickChapterFile(reqId);
  });
}

// ---- Pembungkus pemilihan BANYAK file chapter sekaligus (multi-select) ----
let chapterFilesRequestSeq = 0;
window.onNativeChapterFilesPicked = null;
function pickChapterFiles() {
  return new Promise((resolve) => {
    const reqId = 'cfsreq' + (chapterFilesRequestSeq++);
    window.onNativeChapterFilesPicked = (id, ok, json) => {
      if (id !== reqId) return;
      resolve(ok ? JSON.parse(json) : null);
    };
    Android.pickChapterFiles(reqId);
  });
}

// ---- Tema (Gelap/Terang) — tombol Pengaturan Aplikasi ----
// Disimpan di localStorage (domStorageEnabled aktif di WebView) supaya pilihan
// bertahan lintas sesi tanpa perlu tabel DB baru. Diterapkan sekali di awal (bukan
// per-route) supaya konsisten di semua halaman, termasuk sebelum router jalan.
function getTheme() { return localStorage.getItem('pustaka_theme') || 'dark'; }
function applyTheme(theme) {
  document.body.classList.toggle('theme-light', theme === 'light');
}
function setTheme(theme) {
  localStorage.setItem('pustaka_theme', theme);
  applyTheme(theme);
}
applyTheme(getTheme());

// ---- Mode tampilan daftar (Default / Kotak-kotak) + jumlah kotak per baris ----
// Disimpan di localStorage seperti tema, jadi bertahan lintas sesi.
function getViewMode() { return localStorage.getItem('pustaka_view_mode') === 'grid' ? 'grid' : 'default'; }
function setViewMode(mode) { localStorage.setItem('pustaka_view_mode', mode === 'grid' ? 'grid' : 'default'); }
function getGridCols() {
  const n = parseInt(localStorage.getItem('pustaka_grid_cols'), 10);
  return (n >= 1 && n <= 6) ? n : 2;
}
function setGridCols(n) { localStorage.setItem('pustaka_grid_cols', String(Math.min(6, Math.max(1, n)))); }

// Ukuran kartu tampilan Default (skala 0.6x - 1.6x, 1.0 = ukuran standar)
function getListScale() {
  const n = parseFloat(localStorage.getItem('pustaka_list_scale'));
  return (n >= 0.6 && n <= 1.6) ? n : 1;
}
function setListScale(n) { localStorage.setItem('pustaka_list_scale', String(Math.min(1.6, Math.max(0.6, n)))); }

// ---- Pembungkus Export/Import Backup (data.json + gambar cover jadi satu .zip) ----
let backupRequestSeq = 0;
window.onBackupExported = null;
window.onBackupImported = null;
function exportBackup() {
  return new Promise((resolve) => {
    const reqId = 'bkexp' + (backupRequestSeq++);
    window.onBackupExported = (id, ok) => { if (id !== reqId) return; resolve(ok); };
    Android.exportBackup(reqId);
  });
}
function importBackup() {
  return new Promise((resolve) => {
    const reqId = 'bkimp' + (backupRequestSeq++);
    window.onBackupImported = (id, ok) => { if (id !== reqId) return; resolve(ok); };
    Android.importBackup(reqId);
  });
}

// ---- Router ----
window.addEventListener('hashchange', route);
window.addEventListener('DOMContentLoaded', route);
function nav(hash) { location.hash = hash; }

function route() {
  window.onAppResumed = null; // hanya relevan di halaman tambah/edit; bersihkan saat pindah halaman lain
  const hashRaw = location.hash.slice(1) || '/';
  // PENTING: pisahkan query string (?page=..) SEBELUM pecah jadi segmen path.
  // Tanpa ini, link penanda halaman (yang menambahkan ?page=N) akan membuat
  // "?page=N" ikut nempel di nama file saat dibuka lewat rute 'read', sehingga
  // Android.getChapterInfo() gagal menemukan file & selalu muncul "Tidak Ditemukan"
  // meski file & penandanya valid.
  const hash = hashRaw.split('?')[0] || '/';
  const parts = hash.split('/').filter(Boolean);
  // "Toggle Layar Penuh" di reader menyembunyikan status bar/navigation bar Android
  // (immersive mode) -- itu berlaku di tingkat window Activity, bukan cuma konten
  // WebView, jadi harus dimatikan manual saat pindah ke halaman NON-reader supaya
  // tidak "terbawa" ke daftar/detail/dst.
  document.body.classList.remove('video-fs'); // renderVideoReader memasangnya lagi kalau masih mode layar penuh
  if (parts[0] !== 'read') {
    window.videoFsPref = false; // keluar dari player -> status layar penuh video direset
    if (typeof Android.keepScreenOn === 'function') Android.keepScreenOn(false);
    if (typeof Android.exitFullscreen === 'function') Android.exitFullscreen();
  }
  try {
    if (hash === '/') return renderList();
    if (parts[0] === 'playlists') return renderPlaylists();
    if (parts[0] === 'detail') return renderDetail(parts[1], parseQuery());
    if (parts[0] === 'add') return renderAddEdit(null);
    if (parts[0] === 'edit') return renderAddEdit(parts[1]);
    if (parts[0] === 'edit_chapters') return renderEditChapters(parts[1]);
    if (parts[0] === 'bookmarks') return renderBookmarks(parts[1]);
    if (parts[0] === 'read') return renderReader(decodeURIComponent(parts.slice(1).join('/')));
    renderList();
  } catch (e) {
    app.innerHTML = `<p style="color:#ff4444">Error: ${esc(e.message)}</p><a class="btn-back" href="#/">← Beranda</a>`;
  }
}
function parseQuery() {
  const q = location.hash.split('?')[1];
  const params = {};
  if (q) new URLSearchParams(q).forEach((v, k) => params[k] = v);
  return params;
}

// ============================== LIST (setara /) ==============================
let searchBoxOpen = false;
function renderList() {
  const q = parseQuery();
  const sJudul = q.s_judul || '', sTipe = q.s_tipe || '', sGenre = q.s_genre || '',
        sStatus = q.s_status || '', cat = q.cat || '', fav = q.fav || '0';

  const resJson = Android.listCollections(sJudul, sTipe, sGenre, sStatus, cat, fav);
  const res = JSON.parse(resJson);

  const hasActiveFilter = !!(sJudul || sTipe || sGenre || sStatus);
  if (hasActiveFilter) searchBoxOpen = true;

  const tabs = `
    <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #333; padding-bottom:10px; margin-bottom:15px;">
      <div style="font-size:14px;">
        <a href="#/" style="color:${!cat && fav!=='1' ? '#ffca28':'#888'}; text-decoration:none;">Semua</a>
        <span style="color:#444; margin:0 5px;">|</span>
        <a href="#/?fav=1" style="color:${fav==='1' ? '#ffca28':'#888'}; text-decoration:none;">⭐ Favorit</a>
        ${res.active_playlist_name ? `<span style="color:#444; margin:0 5px;">|</span><span style="color:#ffca28; font-weight:bold;">📁 ${esc(res.active_playlist_name)}</span>` : ''}
      </div>
      <div style="display:flex; gap:8px;">
        <a id="btnToggleSearch" href="javascript:void(0)" style="font-size:20px; text-decoration:none; background:${searchBoxOpen || hasActiveFilter ? '#ffca28' : '#333'}; color:${searchBoxOpen || hasActiveFilter ? '#000' : '#fff'}; padding:5px 12px; border-radius:8px; border:1px solid #555;">🔍</a>
        <a id="btnAppSettings" href="javascript:void(0)" style="font-size:20px; text-decoration:none; background:#333; color:#fff; padding:5px 12px; border-radius:8px; border:1px solid #555;" title="Pengaturan Aplikasi">⚙️</a>
        <a href="#/playlists" style="font-size:20px; text-decoration:none; background:#333; padding:5px 12px; border-radius:8px; border:1px solid #555;">📁</a>
      </div>
    </div>`;

  const searchBox = `
    <div class="search-box" id="searchBox" style="${searchBoxOpen ? '' : 'display:none;'}">
      <h3>--- PENCARIAN SPESIFIK ---</h3>
      <form id="filterForm" class="search-grid">
        <div><label>Judul:</label><input type="text" name="s_judul" value="${esc(sJudul)}"></div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
          <div><label>Tipe:</label><input type="text" name="s_tipe" value="${esc(sTipe)}" placeholder="Manhwa, Anime"></div>
          <div><label>Status:</label><input type="text" name="s_status" value="${esc(sStatus)}" placeholder="Ongoing/Complete"></div>
        </div>
        <div><label>Genre:</label><input type="text" name="s_genre" value="${esc(sGenre)}" placeholder="Action, Fantasy..."></div>
        <button type="submit" style="background:#ffca28; color:black; font-weight:bold; margin-top:8px;">FILTER DATA</button>
      </form>
    </div>`;

  const isGrid = getViewMode() === 'grid';
  const coverSrc = (item) => item.image_path ? Android.getCoverUrl(item.image_path) : BLANK_IMG;
  const cardList = (item) => `
    <a class="manga-card" href="#/detail/${item.id}">
      <img src="${coverSrc(item)}" onerror="this.style.visibility='hidden'">
      <div class="card-info">
        <div class="card-title">${item.is_favorite ? '⭐ ' : ''}${esc(item.title)}</div>
        <div class="card-badges">
          <span class="badge">${esc(item.type||'-')}</span>
          <span class="badge">${esc(item.status||'-')}</span>
        </div>
        <div class="card-meta">${esc(item.chapters || item.episodes || '-')}</div>
      </div>
    </a>`;
  const cardGrid = (item) => `
    <a class="manga-tile" href="#/detail/${item.id}">
      <div class="tile-cover">
        <img src="${coverSrc(item)}" onerror="this.style.visibility='hidden'">
        ${item.is_favorite ? '<span class="tile-fav">⭐</span>' : ''}
      </div>
      <div class="tile-title">${esc(item.title)}</div>
      <div class="tile-badges">
        <span class="badge">${esc(item.type||'-')}</span>
        <span class="badge">${esc(item.status||'-')}</span>
      </div>
      <div class="tile-meta">${esc(item.chapters || item.episodes || '-')}</div>
    </a>`;
  const emptyMsg = `<p style="text-align:center; color:#666; margin-top:40px;">Tidak ada data.</p>`;
  const cards = res.items.length ? res.items.map(isGrid ? cardGrid : cardList).join('') : emptyMsg;
  const listWrapper = (isGrid && res.items.length)
    ? `<div id="listWrap" class="manga-grid" style="--cols:${getGridCols()};">${cards}</div>`
    : `<div id="listWrap" style="--ls:${getListScale()};">${cards}</div>`;

  app.innerHTML = `<h1>📚 Pustaka</h1>${tabs}${searchBox}${listWrapper}<a class="fab" href="#/add">+</a><div id="modalHost"></div>`;

  document.getElementById('btnAppSettings').addEventListener('click', openAppSettingsModal);

  document.getElementById('btnToggleSearch').addEventListener('click', () => {
    searchBoxOpen = !searchBoxOpen;
    const box = document.getElementById('searchBox');
    box.style.display = searchBoxOpen ? '' : 'none';
    const btn = document.getElementById('btnToggleSearch');
    btn.style.background = searchBoxOpen ? '#ffca28' : '#333';
    btn.style.color = searchBoxOpen ? '#000' : '#fff';
  });

  document.getElementById('filterForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    const params = new URLSearchParams();
    for (const [k, v] of f.entries()) if (v) params.set(k, v);
    if (cat) params.set('cat', cat);
    if (fav !== '0') params.set('fav', fav);
    nav('/?' + params.toString());
  });
}


// Gambar ulang daftar di belakang modal Pengaturan supaya perubahan mode/kolom langsung terlihat,
// lalu buka kembali modalnya.
function renderListKeepModal() {
  renderList();
  openAppSettingsModal();
}

// ============================== PENGATURAN APLIKASI (tema, izin, backup) ==============================
function openAppSettingsModal() {
  const host = document.getElementById('modalHost');
  const hasPerm = typeof Android.hasManageStoragePermission === 'function' && Android.hasManageStoragePermission();

  function draw() {
    const theme = getTheme();
    const viewMode = getViewMode();
    const gridCols = getGridCols();
    const listScale = getListScale();
    host.innerHTML = `
      <div class="modal"><div class="modal-content">
        <h3 style="color:#ffca28; margin-top:0;">⚙️ Pengaturan Aplikasi</h3>

        <div class="settings-group" style="margin-bottom:18px;">
          <label>TEMA APLIKASI</label>
          <div class="theme-choice">
            <button id="themeDark" type="button" class="${theme !== 'light' ? 'active' : ''}">🌙 Gelap</button>
            <button id="themeLight" type="button" class="${theme === 'light' ? 'active' : ''}">☀️ Terang</button>
          </div>
        </div>

        <div class="settings-group" style="margin-bottom:18px;">
          <label>TAMPILAN DAFTAR</label>
          <div class="theme-choice">
            <button id="viewDefault" type="button" class="${viewMode !== 'grid' ? 'active' : ''}">☰ Default</button>
            <button id="viewGrid" type="button" class="${viewMode === 'grid' ? 'active' : ''}">▦ Kotak-kotak</button>
          </div>
          ${viewMode !== 'grid' ? `
          <label style="margin-top:12px; display:block;">UKURAN KARTU: <span id="listScaleVal">${Math.round(listScale*100)}%</span></label>
          <div style="display:flex; align-items:center; gap:10px; margin-top:6px;">
            <span style="font-size:12px; color:#888;">Kecil</span>
            <input type="range" id="listScale" min="0.6" max="1.6" step="0.05" value="${listScale}" style="flex:1; margin:0; padding:0;">
            <span style="font-size:16px; color:#888;">Besar</span>
            <button id="listScaleReset" type="button" style="width:auto; padding:4px 10px; font-size:12px;">Reset</button>
          </div>` : ''}
          ${viewMode === 'grid' ? `
          <label style="margin-top:12px; display:block;">JUMLAH KOTAK PER BARIS</label>
          <div class="theme-choice cols-choice">
            ${[1,2,3,4,5].map(n => `<button type="button" data-cols="${n}" class="${gridCols === n ? 'active' : ''}">${n}</button>`).join('')}
          </div>` : ''}
        </div>

        <div class="settings-group" style="margin-bottom:18px;">
          <label>IZIN AKSES PENYIMPANAN</label>
          <div style="display:flex; align-items:center; justify-content:space-between;">
            <span class="status-pill ${hasPerm ? 'ok' : 'warn'}">${hasPerm ? '✔ Aktif' : '✖ Belum Aktif'}</span>
            ${hasPerm ? '' : '<button id="asGrantPerm" type="button" style="width:auto; padding:6px 12px;">Aktifkan</button>'}
          </div>
          <p style="font-size:11px; color:#888; margin:8px 0 0 0;">Dibutuhkan untuk cover di Eksternal Storage &amp; membaca file besar (100MB+) lebih cepat.</p>
        </div>

        ${typeof Android.getServerStatus === 'function' ? `
        <div class="settings-group" style="margin-bottom:18px;">
          <label>🌐 BAGIKAN KE PENGGUNA LAIN (SERVER)</label>
          <div id="srvBody" style="margin-top:6px;"></div>
          <div id="srvPin"></div>
        </div>` : ''}

        <div class="settings-group" style="margin-bottom:5px;">
          <label>BACKUP DATA (Koleksi &amp; Gambar)</label>
          <div style="display:flex; gap:10px;">
            <button id="asExport" type="button" style="flex:1;">⬆️ Export</button>
            <button id="asImport" type="button" style="flex:1;">⬇️ Import</button>
          </div>
          <p style="font-size:11px; color:#888; margin:8px 0 0 0;">Referensi file chapter (pdf/txt/mp4/cbz) tidak ikut ter-backup -- hanya judul, kategori, penanda &amp; gambar cover.</p>
        </div>
        <div id="asStatusMsg" style="font-size:12px; color:#ffca28; margin-top:10px; min-height:16px;"></div>

        <button id="asClose" style="margin-top:15px; background:#444;">Tutup</button>
      </div></div>`;

    document.getElementById('asClose').onclick = () => { host.innerHTML = ''; };
    document.getElementById('themeDark').onclick = () => { setTheme('dark'); draw(); };
    document.getElementById('themeLight').onclick = () => { setTheme('light'); draw(); };
    document.getElementById('viewDefault').onclick = () => { setViewMode('default'); draw(); renderListKeepModal(); };
    document.getElementById('viewGrid').onclick = () => { setViewMode('grid'); draw(); renderListKeepModal(); };
    const scaleEl = document.getElementById('listScale');
    if (scaleEl) {
      const applyScale = (v) => {
        setListScale(v);
        const w = document.getElementById('listWrap');
        if (w) w.style.setProperty('--ls', String(getListScale()));
        document.getElementById('listScaleVal').textContent = Math.round(getListScale() * 100) + '%';
      };
      scaleEl.addEventListener('input', () => applyScale(parseFloat(scaleEl.value)));
      document.getElementById('listScaleReset').onclick = () => { applyScale(1); scaleEl.value = 1; };
    }
    host.querySelectorAll('.cols-choice button').forEach(b => {
      b.onclick = () => { setGridCols(parseInt(b.dataset.cols, 10)); draw(); renderListKeepModal(); };
    });

    const grantBtn = document.getElementById('asGrantPerm');
    if (grantBtn) {
      grantBtn.onclick = () => Android.requestManageStoragePermission();
      // Izin diberikan lewat halaman Settings Android di luar app -- gambar ulang
      // modal ini saat kembali supaya status izin otomatis diperbarui.
      window.onAppResumed = () => openAppSettingsModal();
    }

    const statusMsg = document.getElementById('asStatusMsg');
    document.getElementById('asExport').onclick = async () => {
      statusMsg.textContent = 'Membuat file backup...';
      const ok = await exportBackup();
      statusMsg.textContent = ok ? '✔ Backup berhasil disimpan.' : 'Gagal/dibatalkan membuat backup.';
    };
    document.getElementById('asImport').onclick = async () => {
      if (!confirm('Import akan MENAMBAHKAN koleksi dari file backup ke daftar yang sudah ada (tidak menimpa). Lanjutkan?')) return;
      statusMsg.textContent = 'Memulihkan data dari backup...';
      const ok = await importBackup();
      statusMsg.textContent = ok ? '✔ Data berhasil dipulihkan.' : 'Gagal/dibatalkan memulihkan data.';
      if (ok) renderList();
    };

    initServerBox(statusMsg);
  }

  draw();
}

// ---- Server berbagi: nyalakan/matikan, alamat, dan daftar pengguna + izin edit ----
// Hanya tampil di dalam app (di browser pengguna lain, Android.getServerStatus tidak ada).
function initServerBox(statusMsg) {
  const box = document.getElementById('srvBody');
  if (!box) return;
  paintPin();
  if (window.__srvTimer) { clearInterval(window.__srvTimer); window.__srvTimer = null; }
  box.dataset.sig = '';

  const btnStyle = 'width:auto; padding:4px 10px; font-size:12px;';

  function paint() {
    const el = document.getElementById('srvBody');
    if (!el) { clearInterval(window.__srvTimer); window.__srvTimer = null; return; } // modal sudah ditutup
    let raw = '';
    try { raw = Android.getServerStatus(); } catch (e) { raw = '{"running":false}'; }
    if (el.dataset.sig === raw) return; // tidak ada perubahan -> jangan gambar ulang (tombol tidak "lepas" saat diketuk)
    el.dataset.sig = raw;
    const st = JSON.parse(raw);

    if (!st.running) {
      el.innerHTML = `
        <p style="font-size:11px; color:#888; margin:0 0 8px 0;">Nyalakan agar pengguna lain di Wi-Fi / hotspot yang sama bisa membuka Pustaka lewat browser. Mereka bisa <b>melihat &amp; membaca</b>; untuk <b>mengedit</b> harus minta izin kamu dulu.</p>
        <button id="srvStart" type="button">▶ Nyalakan Server</button>`;
      return;
    }

    const urls = (st.urls && st.urls.length)
      ? st.urls.map(u => `<div style="font-family:monospace; font-size:14px; color:#ffca28; user-select:all; margin:3px 0;">${esc(u)}</div>`).join('')
      : `<div style="font-size:12px; color:#ff8a80;">Belum ada alamat jaringan. Sambungkan HP ke Wi-Fi atau nyalakan hotspot, lalu buka ulang kotak ini.</div>`;

    const clients = (st.clients || []).map(c => {
      const tag = c.pending ? '⏳ minta izin edit' : (c.can_edit ? '✏️ boleh edit' : '👁 lihat saja');
      const btns = c.pending
        ? `<button type="button" data-act="allow" data-id="${esc(c.id)}" style="${btnStyle}">Izinkan</button>
           <button type="button" data-act="deny" data-id="${esc(c.id)}" style="${btnStyle} background:#444;">Tolak</button>`
        : (c.can_edit
            ? `<button type="button" data-act="deny" data-id="${esc(c.id)}" style="${btnStyle} background:#444;">Cabut izin</button>`
            : `<button type="button" data-act="allow" data-id="${esc(c.id)}" style="${btnStyle}">Beri izin edit</button>`);
      return `<div style="display:flex; align-items:center; justify-content:space-between; gap:8px; padding:6px 0; border-top:1px solid #333;">
        <div style="font-size:12px; min-width:0;"><b>${esc(c.name || 'Tanpa nama')}</b> <span style="color:#888;">${esc(c.ip)}</span><br><span style="color:#aaa;">${tag}</span></div>
        <div style="display:flex; gap:6px; flex:none;">${btns}</div></div>`;
    }).join('');

    el.innerHTML = `
      <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:6px;">
        <span class="status-pill ok">✔ Server aktif</span>
        <button id="srvStop" type="button" style="${btnStyle} background:#444;">■ Matikan</button>
      </div>
      <div style="font-size:11px; color:#888;">Minta pengguna lain mengetik alamat ini di browser (HP harus di jaringan yang sama):</div>
      ${urls}
      ${(st.urls && st.urls.length) ? `<button id="srvShare" type="button" style="${btnStyle} margin-top:6px;">📤 Bagikan link</button>` : ''}
      <div style="font-size:11px; color:#888; margin:10px 0 2px 0;">PENGGUNA TERHUBUNG</div>
      ${clients || '<div style="font-size:12px; color:#666;">Belum ada yang terhubung.</div>'}
      <p style="font-size:11px; color:#888; margin:8px 0 0 0;">${st.locked ? 'Pengguna harus memasukkan PIN untuk membuka.' : 'Tanpa PIN, siapa pun di jaringan yang sama yang tahu alamat ini bisa melihat koleksimu.'} Server tetap jalan saat app ditutup; matikan lewat tombol di sini atau di notifikasi.</p>`;
  }

  // Satu handler untuk semua tombol di dalam kotak (isi kotak sering digambar ulang).
  box.onclick = (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.id === 'srvStart') {
      statusMsg.textContent = '';
      let r = {};
      try { r = JSON.parse(Android.startServer()); } catch (err) { r = { error: 'Gagal menyalakan server.' }; }
      if (r.error) statusMsg.textContent = r.error;
    } else if (b.id === 'srvStop') {
      Android.stopServer();
    } else if (b.id === 'srvShare') {
      // Alamat + PIN (kalau ada) dikirim dalam satu pesan lewat menu Bagikan Android.
      let st2 = {}; try { st2 = JSON.parse(Android.getServerStatus()); } catch (err) {}
      const pin = Android.getSharePin();
      const lines = ['Buka Pustaka di browser (harus di Wi-Fi/hotspot yang sama):'].concat(st2.urls || []);
      if (pin) lines.push('PIN: ' + pin);
      Android.shareText(lines.join('\n'));
    } else if (b.dataset.act) {
      Android.setClientEdit(b.dataset.id, b.dataset.act === 'allow');
    } else {
      return;
    }
    box.dataset.sig = '';
    paint();
  };

  paint();
  window.__srvTimer = setInterval(paint, 2000);
}

// Kotak PIN digambar terpisah dari daftar pengguna (yang dipoles ulang tiap 2 detik),
// supaya angka yang sedang diketik tidak terhapus saat ada pengguna baru terhubung.
function paintPin() {
  const el = document.getElementById('srvPin');
  if (!el) return;
  let pin = '';
  try { pin = Android.getSharePin(); } catch (e) {}
  el.innerHTML = `
    <div style="font-size:11px; color:#888; margin:12px 0 4px 0;">🔒 PIN AKSES (opsional)</div>
    <div style="display:flex; gap:6px; align-items:center;">
      <input id="srvPinInput" type="text" inputmode="numeric" maxlength="8" placeholder="4-8 angka" value="${esc(pin)}" style="flex:1; width:auto; min-width:0; margin:0;">
      <button id="srvPinSave" type="button" style="width:auto; padding:6px 12px; flex:none;">Simpan</button>
    </div>
    <div id="srvPinMsg" style="font-size:11px; color:#888; margin-top:4px;">${pin ? 'PIN aktif. Kosongkan lalu Simpan untuk menghapus.' : 'Belum ada PIN — siapa pun di jaringan bisa melihat.'}</div>`;
  document.getElementById('srvPinSave').onclick = () => {
    const v = document.getElementById('srvPinInput').value.trim();
    const r = JSON.parse(Android.setSharePin(v));
    const m = document.getElementById('srvPinMsg');
    if (r.error) { m.style.color = '#ff8a80'; m.textContent = r.error; return; }
    paintPin();
    const m2 = document.getElementById('srvPinMsg');
    m2.style.color = '#8bc34a';
    m2.textContent = v ? '✔ PIN disimpan. Pengguna yang sedang terhubung diminta memasukkan PIN lagi.' : '✔ PIN dihapus.';
    const b = document.getElementById('srvBody'); if (b) b.dataset.sig = ''; // segarkan teks kotak server
  };
}

// ============================== PLAYLISTS (setara /playlists) ==============================
function renderPlaylists() {
  const cats = JSON.parse(Android.listCategories());
  app.innerHTML = `
    <a href="#/" class="btn-back">← Kembali</a>
    <h2>📁 Daftar Playlist</h2>
    <form id="newCatForm" style="margin-bottom:20px; display:flex; gap:8px;">
      <input type="text" name="name" placeholder="Nama Playlist Baru..." required>
      <button type="submit" style="background:#ffca28; color:black; width:auto; white-space:nowrap;">+ Buat</button>
    </form>
    <div id="catList"></div>`;

  const listEl = document.getElementById('catList');
  listEl.innerHTML = cats.map(cat => `
    <div style="display:flex; justify-content:space-between; align-items:center; background:#1e1e1e; padding:12px; margin-bottom:8px; border-radius:8px; border:1px solid #333;">
      <a href="#/?cat=${cat.id}" style="text-decoration:none; color:white; font-weight:bold;">📂 ${esc(cat.name)}</a>
      <button data-id="${cat.id}" class="delCat" style="width:auto; color:#ff4444; background:none; border:none;">Hapus</button>
    </div>`).join('') || `<p style="color:#666;">Belum ada playlist.</p>`;

  listEl.querySelectorAll('.delCat').forEach(btn => btn.addEventListener('click', () => {
    if (confirm('Hapus playlist ini?')) { Android.deleteCategory(parseInt(btn.dataset.id)); renderPlaylists(); }
  }));

  document.getElementById('newCatForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const name = new FormData(e.target).get('name');
    if (name) { Android.addCategory(name); renderPlaylists(); }
  });
}

// ============================== DETAIL (setara /detail/<id>) ==============================
function renderDetail(id, q) {
  const data = JSON.parse(Android.getDetail(parseInt(id)));
  if (data.error) return nav('/');
  const item = data.item;
  const selectedCats = new Set(data.selected_category_ids);

  const chapterRows = data.chapters.length ? data.chapters.map(ch => `
    <div class="chapter-item">
      <a href="#/read/${encodeURIComponent(ch.file_name)}" class="chapter-info" style="flex-grow:1;">
        <span>● ${esc(ch.chapter_name)}</span>
        <small>${esc(ch.upload_date||'')}</small>
      </a>
    </div>`).join('') : `<p style="padding:20px; text-align:center; color:#666; font-size:12px; margin:0;">Belum ada file bacaan/tontonan yang diunggah.</p>`;

  app.innerHTML = `
    <a href="#/" class="btn-back">← Beranda</a>
    <div style="text-align:center; margin-top:10px;">
      <img src="${item.image_path ? Android.getCoverUrl(item.image_path) : BLANK_IMG}" onerror="this.style.visibility='hidden'" style="width:180px; border-radius:10px; border:2px solid #333;">
      <h2 style="margin:15px 0;">${esc(item.title)}</h2>
    </div>
    <div class="description-box"><strong>Sinopsis:</strong><br>${esc(item.description || 'Tidak ada deskripsi.')}</div>
    <ul class="info-list">
      <li><b>Genre:</b> ${esc(item.genre||'-')}</li>
      <li><b>Progress:</b> ${esc(item.chapters || item.episodes || '-')}</li>
      <li><b>Status:</b> ${esc(item.status||'-')}</li>
      <li><b>Tipe:</b> ${esc(item.type)}</li>
    </ul>
    <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #333; padding-bottom:10px; margin-top:30px;">
      <h3 style="margin:0; font-size:16px;">Daftar Isi</h3>
      <div style="display:flex; gap:5px;">
        <a href="#/bookmarks/${item.id}" style="text-decoration:none; background:#333; color:white; padding:6px 12px; border-radius:20px; font-size:12px; font-weight:bold; border:1px solid #555;">🔖 PENANDA</a>
        <a href="#/edit_chapters/${item.id}" style="text-decoration:none; background:#333; color:white; padding:6px 12px; border-radius:20px; font-size:12px; font-weight:bold; border:1px solid #555;">✏️ EDIT</a>
        <button id="btnUpload" style="width:auto; text-decoration:none; background:#ffca28; color:black; padding:6px 12px; border-radius:20px; font-size:12px; font-weight:bold; border:none;">+ TAMBAH</button>
      </div>
    </div>
    <div class="chapter-container">${chapterRows}</div>
    <div class="action-bar">
      <button id="btnPlaylist" class="btn-small-yellow" style="border:none;">🏷 PLAYLIST</button>
      <a href="#/edit/${item.id}" class="btn-small-outline">📝 EDIT DATA</a>
      <button id="btnDelete" class="btn-small-red" style="border:none;">🗑️ HAPUS</button>
    </div>
    <div id="modalHost"></div>`;

  document.getElementById('btnDelete').addEventListener('click', () => {
    if (confirm('Hapus?')) { Android.deleteCollection(item.id); nav('/'); }
  });
  document.getElementById('btnUpload').addEventListener('click', () => openUploadModal(item.id));
  document.getElementById('btnPlaylist').addEventListener('click', () => openPlaylistModal(item, data.all_categories, selectedCats));
}

// Chapter (pdf/txt/mp4/cbz) TIDAK diunggah/disalin ke storage app. User langsung memilih
// SATU file lewat picker file bawaan Android (SAF) -- app TIDAK menjelajahi/membaca isi
// folder mana pun, hanya menyimpan ALAMAT (content URI) file yang dipilih, lalu membacanya
// langsung dari alamat itu setiap dibutuhkan.
function openUploadModal(collId) {
  const host = document.getElementById('modalHost');
  let picked = []; // [{ uri, name }]
  const hasPerm = typeof Android.hasManageStoragePermission === 'function' && Android.hasManageStoragePermission();
  const baseName = (n) => n.replace(/\.(pdf|txt|mp4|cbz)$/i, '');
  const natural = (a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });

  host.innerHTML = `
    <div class="modal"><div class="modal-content">
      <h3 style="color:#ffca28; margin-top:0;">Upload File Baru</h3>
      <p style="font-size:13px; color:#aaa; line-height:1.5; margin-bottom:10px;">
        Pilih <b>satu atau BANYAK file</b> sekaligus (PDF/TXT/MP4/CBZ). Nama chapter otomatis
        diambil dari nama file dan diurutkan angka (1, 2, ... 10). File <b>tidak</b> disalin
        ke penyimpanan app.
      </p>
      ${hasPerm ? '' : `
      <div style="background:#332b12; border:1px solid #665a26; border-radius:6px; padding:10px; margin-bottom:12px; font-size:12px; color:#ffca28; line-height:1.5;">
        ⚠️ Untuk file BESAR (100MB+) agar terbaca cepat &amp; lancar, aktifkan dulu izin
        "Kelola Semua File" -- tanpa izin ini, file besar bisa lambat/gagal dibaca.
        <button id="chGrantPerm" type="button" style="margin-top:8px; width:auto; padding:6px 12px; font-size:12px; background:#ffca28; color:black; font-weight:bold;">Aktifkan Izin</button>
      </div>`}
      <button id="chPickFile" type="button">📄 Pilih File (bisa banyak)...</button>
      <div id="chPicked" style="font-size:12px; color:#888; margin:10px 0; max-height:160px; overflow-y:auto;">Belum ada file dipilih.</div>
      <label id="chNameLbl" style="font-size:12px; color:#888; display:none;">Nama Chapter/Episode (opsional, kosongkan untuk pakai nama file):</label>
      <input id="chName" type="text" placeholder="Contoh: EPISODE 1" style="margin-bottom:15px; display:none;">

      <div style="display:flex; gap:10px;">
        <button id="chCancel" style="flex:1; background:#444;">Batal</button>
        <button id="chSubmit" style="flex:1; background:#ffca28; color:black; font-weight:bold;">Upload</button>
      </div>
    </div></div>`;

  document.getElementById('chCancel').onclick = () => host.innerHTML = '';
  const grantBtn = document.getElementById('chGrantPerm');
  if (grantBtn) {
    grantBtn.onclick = () => Android.requestManageStoragePermission();
    window.onAppResumed = () => openUploadModal(collId);
  }

  document.getElementById('chPickFile').onclick = async () => {
    const res = await pickChapterFiles();
    if (!res || !res.length) return;
    const ok = res.filter(f => /\.(pdf|txt|mp4|cbz)$/i.test(f.name));
    const skipped = res.length - ok.length;
    if (skipped > 0) alert(skipped + ' file dilewati karena formatnya tidak didukung (hanya PDF/TXT/MP4/CBZ).');
    if (!ok.length) return;
    picked = ok.sort(natural);
    document.getElementById('chPicked').innerHTML =
      '<div style="color:#ffca28; margin-bottom:4px;">✔ ' + picked.length + ' file dipilih:</div>' +
      picked.map(f => '<div>• ' + esc(f.name) + '</div>').join('');
    const single = picked.length === 1;
    document.getElementById('chName').style.display = single ? '' : 'none';
    document.getElementById('chNameLbl').style.display = single ? '' : 'none';
  };

  document.getElementById('chSubmit').onclick = () => {
    if (!picked.length) { alert('Pilih file terlebih dahulu.'); return; }
    const typed = document.getElementById('chName').value.trim();
    let fail = 0;
    picked.forEach((f) => {
      const chName = (picked.length === 1 && typed) ? typed : baseName(f.name);
      const payload = { ch_name: chName, file_relpath: f.uri + '|' + f.name };
      const res = JSON.parse(Android.addChapter(collId, JSON.stringify(payload)));
      if (res.error) fail++;
    });
    if (fail) alert(fail + ' file gagal ditambahkan (tidak ditemukan/tidak didukung).');
    host.innerHTML = '';
    renderDetail(String(collId), {});
  };
}

function openPlaylistModal(item, allCategories, selectedCats) {
  const host = document.getElementById('modalHost');
  host.innerHTML = `
    <div class="modal"><div class="modal-content">
      <h3>Kelola Penyimpanan</h3>
      <label style="display:block; margin-bottom:15px; background:#2a2a2a; padding:10px; border-radius:5px;">
        <input type="checkbox" id="isFav" ${item.is_favorite ? 'checked' : ''} style="width:auto;"> ⭐ Favorit
      </label>
      <hr style="border-color:#333;">
      <div style="max-height:150px; overflow-y:auto; margin:15px 0;">
        ${allCategories.map(cat => `
          <label style="display:block; margin-bottom:8px;">
            <input type="checkbox" class="catCk" value="${cat.id}" ${selectedCats.has(cat.id) ? 'checked' : ''} style="width:auto;"> 📂 ${esc(cat.name)}
          </label>`).join('')}
      </div>
      <div style="display:flex; gap:10px;">
        <button id="plCancel" style="flex:1; background:#444;">Batal</button>
        <button id="plSave" style="flex:1; background:#ffca28; color:black;">Simpan</button>
      </div>
    </div></div>`;
  document.getElementById('plCancel').onclick = () => host.innerHTML = '';
  document.getElementById('plSave').onclick = () => {
    const isFav = document.getElementById('isFav').checked;
    const catIds = Array.from(document.querySelectorAll('.catCk:checked')).map(c => c.value).join(',');
    Android.updateItemCategories(item.id, isFav, catIds);
    host.innerHTML = '';
    renderDetail(String(item.id), {});
  };
}

// ============================== ADD / EDIT (setara /add, /edit/<id>) ==============================
function renderAddEdit(id) {
  const isEdit = !!id;
  const item = isEdit ? JSON.parse(Android.getDetail(parseInt(id))).item : null;

  app.innerHTML = `
    <a href="${isEdit ? '#/detail/'+id : '#/'}" class="btn-back">← Batal</a>
    <h2>${isEdit ? 'Edit Data' : 'Tambah Koleksi'}</h2>
    <div class="search-grid" style="gap:10px;">
      <div><label style="font-size:12px; color:#888;">Judul:</label><input id="fTitle" value="${item ? esc(item.title):''}" required></div>
      <div><label style="font-size:12px; color:#888;">Tipe:</label><input id="fType" value="${item ? esc(item.type):''}" placeholder="Manhwa, Anime, dll" required></div>
      <div><label style="font-size:12px; color:#888;">Genre:</label><input id="fGenre" value="${item ? esc(item.genre):''}" placeholder="Action, Romance..."></div>
      <div><label style="font-size:12px; color:#888;">Status:</label><input id="fStatus" value="${item ? esc(item.status):''}" placeholder="Ongoing/Complete"></div>
      <div><label style="font-size:12px; color:#888;">Chapter/Episode (Progress):</label><input id="fChapters" value="${item ? esc(item.chapters||item.episodes):''}"></div>
      <div><label style="font-size:12px; color:#888;">Sinopsis:</label><textarea id="fDesc" style="height:120px;">${item ? esc(item.description):''}</textarea></div>
      <div><label style="font-size:12px; color:#888;">Lokasi Simpan Cover:</label>
        <select id="fStorage"><option value="internal">Internal Storage</option><option value="eksternal">Eksternal Storage</option></select>
        <div id="fStorageWarn" style="font-size:11px; color:#ffca28; margin-top:6px; display:none;">
          ⚠️ Izin "Kelola semua file" belum diberikan -- cover akan tetap tersimpan di Internal Storage sampai izin diberikan.
          <button id="fStorageGrant" type="button" style="width:auto; padding:4px 10px; margin-top:6px; background:#ffca28; color:black; font-weight:bold;">Berikan Izin</button>
        </div>
      </div>
      <div>
        <label style="font-size:12px; color:#888;">Gambar Cover:</label>
        <button id="fPickImg">🖼️ ${isEdit ? 'Ganti Gambar (opsional)' : 'Pilih Gambar (opsional)'}</button>
        <div id="fImgPreview" style="font-size:12px; color:#888; margin-top:6px;"></div>
      </div>
      <button id="fSubmit" style="background:#ffca28; color:black; font-weight:bold; margin-top:10px;">${isEdit ? 'Update' : 'Simpan Koleksi'}</button>
    </div>`;

  let pickedImage = null;
  document.getElementById('fPickImg').addEventListener('click', async () => {
    const f = await pickNativeImage();
    if (f) { pickedImage = f; document.getElementById('fImgPreview').textContent = '✔ ' + f.filename; }
  });

  // "Eksternal Storage" butuh izin runtime Android ("Kelola semua file") yang tidak
  // dibutuhkan versi Flask (yang punya akses filesystem penuh) -- tanpa ini, memilih
  // Eksternal Storage akan diam-diam jatuh balik ke Internal Storage tanpa penjelasan.
  const fStorage = document.getElementById('fStorage');
  const fStorageWarn = document.getElementById('fStorageWarn');
  const fStorageGrant = document.getElementById('fStorageGrant');
  function refreshStorageWarn() {
    const hasPerm = typeof Android.hasManageStoragePermission === 'function' && Android.hasManageStoragePermission();
    fStorageWarn.style.display = (fStorage.value === 'eksternal' && !hasPerm) ? 'block' : 'none';
  }
  fStorage.addEventListener('change', refreshStorageWarn);
  fStorageGrant.addEventListener('click', () => Android.requestManageStoragePermission());
  refreshStorageWarn();
  // Izin diberikan lewat halaman Settings Android di luar app -- saat user kembali
  // (app di-resume), cek ulang statusnya supaya peringatan hilang otomatis.
  window.onAppResumed = refreshStorageWarn;

  document.getElementById('fSubmit').addEventListener('click', () => {
    const title = document.getElementById('fTitle').value.trim();
    const type = document.getElementById('fType').value.trim();
    if (!title || !type) { alert('Judul dan Tipe wajib diisi.'); return; }
    const payload = {
      title, type,
      genre: document.getElementById('fGenre').value,
      status: document.getElementById('fStatus').value,
      chapters: document.getElementById('fChapters').value,
      description: document.getElementById('fDesc').value,
      storage_location: document.getElementById('fStorage').value
    };
    if (pickedImage) { payload.image_base64 = pickedImage.base64; payload.image_file_name = pickedImage.filename; }

    if (isEdit) { Android.editCollection(parseInt(id), JSON.stringify(payload)); nav('/detail/' + id); }
    else {
      const res = JSON.parse(Android.addCollection(JSON.stringify(payload)));
      nav('/detail/' + res.id);
    }
  });
}

// ============================== EDIT CHAPTERS (reorder) ==============================
function renderEditChapters(id) {
  const data = JSON.parse(Android.getDetail(parseInt(id)));
  const item = data.item;
  app.innerHTML = `
    <a href="#/detail/${id}" class="btn-back">← Kembali</a>
    <h2>Edit Daftar Isi</h2>
    <p style="font-size:12px; color:#888;">Gunakan tombol panah untuk menggeser urutan, dan edit teks untuk mengubah nama.</p>
    <div id="chList"></div>
    <button id="saveOrder" style="background:#ffca28; color:black; font-weight:bold; margin-top:15px; padding:12px;">SIMPAN PERUBAHAN</button>`;

  const listEl = document.getElementById('chList');
  function draw() {
    listEl.innerHTML = data.chapters.map(ch => `
      <div class="chapter-edit-row" data-id="${ch.id}" style="display:flex; align-items:center; gap:12px; margin-bottom:10px; background:#1e1e1e; padding:12px; border-radius:8px; border:1px solid #333;">
        <div style="display:flex; flex-direction:column; gap:5px;">
          <button class="mvUp" style="padding:4px 10px; margin:0; background:#444; border:none; color:white; border-radius:4px; width:auto;">▲</button>
          <button class="mvDown" style="padding:4px 10px; margin:0; background:#444; border:none; color:white; border-radius:4px; width:auto;">▼</button>
        </div>
        <input type="text" class="chNameInput" value="${esc(ch.chapter_name)}" style="flex-grow:1; margin:0; font-weight:bold;">
        <button class="delCh" style="color:#ff4444; background:none; border:1px solid #ff4444; border-radius:4px; width:auto; padding:8px;">Hapus</button>
      </div>`).join('');
    listEl.querySelectorAll('.mvUp').forEach((btn, i) => btn.onclick = () => { if (i>0) { [data.chapters[i-1], data.chapters[i]] = [data.chapters[i], data.chapters[i-1]]; draw(); } });
    listEl.querySelectorAll('.mvDown').forEach((btn, i) => btn.onclick = () => { if (i<data.chapters.length-1) { [data.chapters[i+1], data.chapters[i]] = [data.chapters[i], data.chapters[i+1]]; draw(); } });
    listEl.querySelectorAll('.delCh').forEach((btn, i) => btn.onclick = () => {
      if (confirm('Hapus file ini?')) { Android.deleteChapter(data.chapters[i].id); data.chapters.splice(i,1); draw(); }
    });
  }
  draw();

  document.getElementById('saveOrder').addEventListener('click', () => {
    const rows = listEl.querySelectorAll('.chapter-edit-row');
    const payload = Array.from(rows).map((row, idx) => ({
      id: parseInt(row.dataset.id),
      name: row.querySelector('.chNameInput').value,
      order: idx + 1
    }));
    Android.editChapters(JSON.stringify(payload));
    nav('/detail/' + id);
  });
}

// ============================== BOOKMARKS ==============================
function renderBookmarks(collId) {
  const item = JSON.parse(Android.getDetail(parseInt(collId))).item;
  const bookmarks = JSON.parse(Android.listBookmarks(parseInt(collId)));
  app.innerHTML = `
    <a href="#/detail/${collId}" class="btn-back">← Kembali</a>
    <h2>🔖 Penanda Halaman</h2>
    <h3 style="color:#ffca28; margin-bottom:20px; border-bottom:1px solid #333; padding-bottom:10px;">${esc(item.title)}</h3>
    <div class="chapter-container" style="max-height:none;">
      ${bookmarks.length ? bookmarks.map(bm => `
        <div class="chapter-item">
          <a href="#/read/${encodeURIComponent(bm.file_name)}?page=${bm.page_index}" class="chapter-info" style="flex-grow:1;">
            <span>● ${esc(bm.chapter_name)}</span>
            <small style="color:#ffca28; font-weight:bold;">${bm.file_name.toLowerCase().endsWith('.txt') ? 'Posisi Scroll: '+bm.page_index : bm.file_name.toLowerCase().endsWith('.mp4') ? 'Posisi Tonton: '+fmtTime(bm.page_index) : 'Halaman: '+(bm.page_index+1)}</small>
          </a>
          <button data-id="${bm.id}" class="delBm" style="background:#442222; border-radius:4px; padding:6px 12px; color:#ff4444; border:none; width:auto;">Hapus</button>
        </div>`).join('') : `<p style="padding:20px; text-align:center; color:#666; font-size:12px; margin:0;">Belum ada halaman yang ditandai.</p>`}
    </div>`;
  document.querySelectorAll('.delBm').forEach(btn => btn.onclick = () => {
    if (confirm('Hapus penanda ini?')) { Android.deleteBookmark(parseInt(btn.dataset.id)); renderBookmarks(collId); }
  });
}

// ============================== READER (setara /read/<filename>) ==============================
function renderReader(fileName) {
  const q = parseQuery();
  const pageParam = q.page !== undefined ? parseInt(q.page) : NaN;
  const info = JSON.parse(Android.getChapterInfo(fileName));
  const chMeta = JSON.parse(Android.getChapterIdByFileName(fileName));

  if (info.error) {
    const msg = info.error === 'read_failed'
      ? 'Gagal membaca isi file ini (format mungkin rusak, atau file terlalu besar/lambat diakses dari lokasi penyimpanannya).'
      : 'Gagal memuat file.<br>File ini mungkin telah dihapus secara manual lewat File Manager atau dipindahkan.';
    app.innerHTML = `<div style="text-align:center; padding:60px 20px; color:#ffca28;">
      <h2>⚠️ ${info.error === 'read_failed' ? 'Gagal Membaca File' : 'File Tidak Ditemukan'}</h2><p>${msg}</p><br>
      <a href="javascript:history.back()" class="btn-back">Kembali</a></div>`;
    return;
  }

  if ((info.ext === 'pdf' || info.ext === 'cbz') && !info.page_count) {
    app.innerHTML = `<div style="text-align:center; padding:60px 20px; color:#ffca28;">
      <h2>⚠️ Tidak Ada Halaman</h2><p>File ini terbaca tapi tidak ada halaman gambar di dalamnya
      (untuk CBZ: pastikan isinya benar-benar file gambar, bukan sub-folder gambar).</p><br>
      <a href="javascript:history.back()" class="btn-back">Kembali</a></div>`;
    return;
  }

  if (info.ext === 'pdf') return renderPagedReader(fileName, info.page_count, (i) => Android.getPdfPageUrl(fileName, i), chMeta, pageParam);
  if (info.ext === 'cbz') return renderPagedReader(fileName, info.page_count, (i) => Android.getCbzPageUrl(fileName, i), chMeta, pageParam);
  if (info.ext === 'txt') return renderNovelReader(info.text, chMeta, pageParam);
  if (info.ext === 'mp4') return renderVideoReader(fileName, chMeta, pageParam);

  // Setara fallback Python (`redirect(url_for('view_file', filename=filename))` untuk
  // ekstensi tak dikenal): tidak ada browser bawaan di app native, jadi serahkan ke
  // aplikasi lain di perangkat lewat "Buka dengan...".
  Android.openWithExternalApp(fileName);
  nav('/');
}

function bookmarkPage(chMeta, pageIndex, doneMsg) {
  if (!chMeta.chapter_id) { alert('Gagal menambahkan penanda halaman.'); return; }
  Android.addBookmark(chMeta.chapter_id, chMeta.collection_id, pageIndex);
  alert(doneMsg || ('Halaman ' + (pageIndex + 1) + ' berhasil ditandai!'));
}

// ---- Reader per-halaman (CBZ & PDF) — identik UI/fitur dgn versi Flask ----
function renderPagedReader(fileName, pageCount, pageUrlFn, chMeta, pageParam) {
  app.innerHTML = `
    <div class="reader-nav" id="reader-nav">
      <a href="javascript:history.back()" class="btn-back">← Kembali</a>
      <div style="display:flex; align-items:center;">
        <button id="btnBookmark" style="background:none; border:none; color:#ffca28; font-size:20px; margin-right:15px; width:auto;" title="Tandai Halaman">🔖</button>
        <button id="btnSettings" style="background:none; border:none; color:#ffca28; font-size:20px; width:auto;" title="Pengaturan">⚙️</button>
      </div>
    </div>

    <div id="settings-modal">
      <h4 style="margin-top:0; color:#ffca28; border-bottom:1px solid #333; padding-bottom:5px; margin-bottom:15px;">Gaya Membaca</h4>
      <div class="settings-group">
        <label>A. IMAGE FIT TO SCREEN</label>
        <select id="fit-select">
          <option value="off">4. Off (Default)</option>
          <option value="height">1. Fit Height</option>
          <option value="width">2. Fit Width</option>
          <option value="full">3. Full Screen</option>
        </select>
      </div>
      <div class="settings-group">
        <label>B. PAGE SCROLLING</label>
        <select id="scroll-select">
          <option value="vertical">0. Vertical (Default)</option>
          <option value="right-page">1. Right (Berpindah 1 Gambar)</option>
          <option value="left-page">2. Left (Berpindah 1 Gambar)</option>
          <option value="right-scroll">3. Right Scroll (Terhubung)</option>
          <option value="left-scroll">4. Left Scroll (Terhubung)</option>
        </select>
      </div>
      <button id="btnFullscreen" style="margin-top:10px;">Toggle Layar Penuh</button>
    </div>

    <div class="comic-container" id="comic-container"></div>

    <button class="toggle-thumb-btn" id="btnToggleThumb">📑</button>
    <div class="thumb-nav hidden" id="thumb-nav">
      <div class="thumb-container" id="thumb-container"></div>
      <div class="range-container">
        <span id="page-indicator">1 / ${pageCount}</span>
        <input type="range" id="page-slider" min="0" max="${Math.max(0, pageCount - 1)}" value="0">
      </div>
    </div>`;

  const container = document.getElementById('comic-container');
  const thumbContainer = document.getElementById('thumb-container');
  let currentPage = 0;
  const imagesElems = [];

  // Buat elemen gambar per-halaman dgn placeholder + lazy load manual (persis versi Flask)
  for (let i = 0; i < pageCount; i++) {
    const img = document.createElement('img');
    img.dataset.src = pageUrlFn(i);
    img.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 800 1200' fill='%23111'%3E%3C/svg%3E";
    container.appendChild(img);
    imagesElems.push(img);

    const thumb = document.createElement('img');
    thumb.loading = 'lazy';
    thumb.src = pageUrlFn(i);
    thumb.className = 'thumb-item';
    thumb.id = 'thumb-' + i;
    thumb.onclick = () => goToPage(i);
    thumbContainer.appendChild(thumb);
  }

  const lazyLoadObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        if (img.dataset.src) { img.src = img.dataset.src; delete img.dataset.src; observer.unobserve(img); }
      }
    });
  }, { rootMargin: '300% 0px' });
  imagesElems.forEach(img => lazyLoadObserver.observe(img));

  const pageObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const index = imagesElems.indexOf(entry.target);
        if (index !== -1 && index !== currentPage) { currentPage = index; updateIndicators(); }
      }
    });
  }, { root: null, threshold: 0.1 });
  imagesElems.forEach(img => pageObserver.observe(img));

  function updateIndicators() {
    document.getElementById('page-slider').value = currentPage;
    document.getElementById('page-indicator').innerText = (currentPage + 1) + ' / ' + pageCount;
    document.querySelectorAll('.thumb-item').forEach((el, idx) => {
      if (idx === currentPage) { el.classList.add('active'); el.scrollIntoView({ behavior:'smooth', inline:'center', block:'nearest' }); }
      else el.classList.remove('active');
    });
  }
  function goToPage(index) {
    index = Math.max(0, Math.min(pageCount - 1, parseInt(index)));
    const isLongJump = Math.abs(currentPage - index) > 3;
    currentPage = index;
    const target = imagesElems[index];
    if (target.dataset.src) { target.src = target.dataset.src; delete target.dataset.src; }
    target.scrollIntoView({ behavior: isLongJump ? 'auto' : 'smooth', inline:'center', block:'start' });
    updateIndicators();
  }

  document.getElementById('page-slider').addEventListener('input', (e) => goToPage(e.target.value));
  document.getElementById('btnToggleThumb').onclick = () => document.getElementById('thumb-nav').classList.toggle('hidden');
  document.getElementById('btnSettings').onclick = () => {
    const modal = document.getElementById('settings-modal');
    modal.style.display = modal.style.display === 'block' ? 'none' : 'block';
  };
  document.getElementById('fit-select').addEventListener('change', applyReaderSettings);
  document.getElementById('scroll-select').addEventListener('change', applyReaderSettings);
  document.getElementById('btnFullscreen').onclick = () => Android.toggleFullscreen();
  document.getElementById('btnBookmark').onclick = () => bookmarkPage(chMeta, currentPage);

  function applyReaderSettings() {
    const fit = document.getElementById('fit-select').value;
    const scroll = document.getElementById('scroll-select').value;
    container.className = 'comic-container';
    container.dir = 'ltr';
    if (fit === 'height') container.classList.add('fit-height');
    else if (fit === 'width') container.classList.add('fit-width');
    else if (fit === 'full') container.classList.add('fit-full');
    if (scroll !== 'vertical') {
      container.classList.add('scroll-h');
      if (scroll.includes('right')) container.dir = 'rtl';
      if (scroll.includes('page')) container.classList.add('scroll-paginated');
    }
  }

  // Lompat ke halaman dari penanda (kalau ada ?page=)
  if (!isNaN(pageParam) && pageParam >= 0 && pageParam < pageCount) {
    currentPage = pageParam;
    for (let i = Math.max(0, pageParam - 2); i <= Math.min(pageCount - 1, pageParam + 2); i++) {
      if (imagesElems[i].dataset.src) { imagesElems[i].src = imagesElems[i].dataset.src; delete imagesElems[i].dataset.src; }
    }
    setTimeout(() => { imagesElems[pageParam].scrollIntoView({ behavior:'auto', inline:'center', block:'start' }); updateIndicators(); }, 50);
  } else {
    updateIndicators();
  }
}

// ---- Reader Novel/TXT — identik styling dgn versi Flask ----
function renderNovelReader(text, chMeta, pageParam) {
  app.innerHTML = `
    <style>
      body { background-color:#1a1a1a !important; color:#d4d4d4 !important; }
      .novel-container { max-width:800px; margin:80px auto 50px auto; padding:0 20px; font-size:18px; line-height:1.8; white-space:pre-wrap; font-family:'Georgia', serif; }
    </style>
    <div class="reader-nav" style="background:rgba(20,20,20,0.95);">
      <a href="javascript:history.back()" class="btn-back">← Kembali</a>
      <button id="btnBookmark" style="background:none; border:none; color:#ffca28; font-size:20px; width:auto;" title="Tandai Posisi">🔖</button>
    </div>
    <div class="novel-container">${esc(text)}</div>`;

  document.getElementById('btnBookmark').onclick = () => bookmarkPage(chMeta, Math.round(window.scrollY), 'Posisi membaca berhasil ditandai!');

  if (!isNaN(pageParam)) {
    setTimeout(() => window.scrollTo({ top: pageParam, behavior: 'auto' }), 200);
  }
}

// ---- Reader Video/MP4 — player kustom ----
// Portrait : video 16:9 di atas (tombol play besar di tengah + seek bar), toolbar (kecepatan /
//            episode / tampilan / layar penuh) & daftar penanda menit di panel bawah video.
// Fullscreen: video memenuhi layar (immersive + landscape), toolbar pindah masuk ke overlay.
function renderVideoReader(fileName, chMeta, pageParam) {
  chMeta = chMeta || {};
  let videoChapters = [];
  let currentIndex = -1;
  let collTitle = '';
  if (chMeta.collection_id) {
    try {
      const detail = JSON.parse(Android.getDetail(chMeta.collection_id));
      const chapters = (detail && detail.chapters) ? detail.chapters : [];
      collTitle = (detail && detail.item && detail.item.title) ? detail.item.title : '';
      videoChapters = chapters.filter(c => (c.file_name || '').toLowerCase().endsWith('.mp4'));
      currentIndex = videoChapters.findIndex(c => c.file_name === fileName);
    } catch (e) { /* koleksi/chapter tak ditemukan, lanjut tanpa navigasi episode */ }
  }
  const prevCh = currentIndex > 0 ? videoChapters[currentIndex - 1] : null;
  const nextCh = (currentIndex >= 0 && currentIndex < videoChapters.length - 1) ? videoChapters[currentIndex + 1] : null;
  const chapterTitle = currentIndex >= 0 ? videoChapters[currentIndex].chapter_name : fileName;

  const ic = {
    lock: '<svg viewBox="0 0 24 24"><path d="M12 17a2 2 0 0 0 2-2 2 2 0 0 0-2-2 2 2 0 0 0-2 2 2 2 0 0 0 2 2zm6-9h-1V6a5 5 0 0 0-10 0v2H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zM8.9 6c0-1.71 1.39-3.1 3.1-3.1s3.1 1.39 3.1 3.1v2H8.9V6zM18 20H6V10h12v10z"/></svg>',
    unlock: '<svg viewBox="0 0 24 24"><path d="M12 17a2 2 0 0 0 2-2 2 2 0 0 0-2-2 2 2 0 0 0-2 2 2 2 0 0 0 2 2zm6-11h-9V6a3 3 0 0 1 6 0h2a5 5 0 0 0-10 0v2H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zM18 20H6V10h12v10z"/></svg>',
    bookmark: '<svg viewBox="0 0 24 24"><path d="M17 3H7c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2z"/></svg>',
    back: '<svg viewBox="0 0 24 24"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>',
    collapse: '<svg viewBox="0 0 24 24"><path d="M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6z"/></svg>',
    rewind: '<svg viewBox="0 0 24 24"><path d="M11 18V6l-8.5 6zM21 18V6l-8.5 6z"/></svg>',
    forward: '<svg viewBox="0 0 24 24"><path d="M13 6v12l8.5-6zM3 6v12l8.5-6z"/></svg>',
    repeat: '<svg viewBox="0 0 24 24"><path d="M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4z"/></svg>',
    aspect: '<svg viewBox="0 0 24 24"><path d="M19 12h-2v3h-3v2h5v-5zM7 9h3V7H5v5h2V9zm14-6H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16.01H3V4.99h18v14.02z"/></svg>',
    fsOn: '<svg viewBox="0 0 24 24"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/></svg>',
    fsOff: '<svg viewBox="0 0 24 24"><path d="M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z"/></svg>',
    prev: '<svg viewBox="0 0 24 24"><path d="M6 6h2v12H6zm3.5 6 8.5 6V6z"/></svg>',
    next: '<svg viewBox="0 0 24 24"><path d="M16 6h2v12h-2zM6 6l8.5 6L6 18z"/></svg>',
    rotate: '<svg viewBox="0 0 24 24"><path d="M16.48 2.52c3.27 1.55 5.61 4.72 5.97 8.48h1.5C23.44 4.84 18.29 0 12 0l-.66.03 3.81 3.81 1.33-1.32zm-6.25-.77c-.59-.59-1.54-.59-2.12 0L1.75 8.11c-.59.59-.59 1.54 0 2.12l12.02 12.02c.59.59 1.54.59 2.12 0l6.36-6.36c.59-.59.59-1.54 0-2.12L10.23 1.75zm4.6 19.44L2.81 9.17l6.36-6.36 12.02 12.02-6.36 6.36zm-7.31.29C4.25 19.94 1.91 16.76 1.55 13H.05C.56 19.16 5.71 24 12 24l.66-.03-3.81-3.81-1.33 1.32z"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>',
    pause: '<svg viewBox="0 0 24 24"><path d="M6 5h4v14H6zm8 0h4v14h-4z"/></svg>',
  };

  app.innerHTML = `
    <div class="video-shell" id="videoShell">
      <div class="video-player-wrap" id="videoWrap">
        <video id="videoEl" src="${Android.getChapterPlayUrl(fileName)}" playsinline webkit-playsinline preload="auto"></video>

        <div class="video-tap-zone video-tap-left" id="tapLeft"></div>
        <div class="video-tap-zone video-tap-mid" id="tapMid"></div>
        <div class="video-tap-zone video-tap-right" id="tapRight"></div>
        <div class="video-seek-flash video-seek-flash-left" id="flashLeft">${ic.rewind}<span>10 detik</span></div>
        <div class="video-seek-flash video-seek-flash-right" id="flashRight">${ic.forward}<span>10 detik</span></div>

        <div class="video-loading" id="videoLoading"><div class="video-spinner"></div></div>
        <div class="video-toast" id="videoToast"></div>

        <div class="video-next-cta hidden" id="nextCta">
          <p>Video Selesai</p>
          ${nextCh ? `<button id="btnNextCta">▶ Lanjut: ${esc(nextCh.chapter_name)}</button>` : ''}
          <button id="btnReplayCta" class="video-next-cta-secondary">↻ Putar Ulang</button>
        </div>

        <button id="btnLockFloating" class="video-lock-floating hidden" title="Buka Kunci">${ic.unlock}</button>

        <div class="video-overlay" id="videoOverlay">
          <div class="video-top-icons">
            <button id="btnVideoBack" class="vctrl-top-btn video-back-btn" title="Kembali">${ic.back}</button>
            <button id="btnVideoBookmark" class="vctrl-top-btn" title="Tandai menit ini">${ic.bookmark}</button>
            <button id="btnRepeat" class="vctrl-top-btn" title="Ulangi Video">${ic.repeat}</button>
            <button id="btnLock" class="vctrl-top-btn" title="Kunci Layar">${ic.lock}</button>
            <button id="btnCollapse" class="vctrl-top-btn" title="Sembunyikan Kontrol">${ic.collapse}</button>
          </div>

          <div class="video-center-controls">
            <button id="btnRewind10" class="vctrl-side-btn" title="Mundur 10 detik">${ic.rewind}<small>10</small></button>
            <button id="btnPlayPause" class="vctrl-big" title="Main / Jeda">
              <span id="iconPlay">${ic.play}</span>
              <span id="iconPause" style="display:none;">${ic.pause}</span>
            </button>
            <button id="btnForward10" class="vctrl-side-btn" title="Maju 10 detik">${ic.forward}<small>10</small></button>
          </div>

          <div class="video-bottom-controls" id="videoBottom">
            <div class="video-seek-row">
              <span id="timeCurrent" class="video-time">0:00</span>
              <div class="video-seek-wrap">
                <div class="video-seek-marks" id="seekMarks"></div>
                <input type="range" id="seekBar" class="video-seek" min="0" max="1000" value="0" step="0.1">
              </div>
              <span id="timeDuration" class="video-time">0:00</span>
            </div>
          </div>
        </div>
      </div>

      <div class="video-info" id="videoInfo">
        <div class="video-tools" id="videoTools">
          <button id="btnSpeed" class="vtool" title="Kecepatan Putar"><span class="vtool-ico" id="speedIco">1X</span><span class="lbl">Kecepatan</span></button>
          <button id="btnPrevChapter" class="vtool" ${prevCh ? '' : 'disabled'} title="Episode Sebelumnya">${ic.prev}<span class="lbl">Sebelumnya</span></button>
          <button id="btnNextChapter" class="vtool" ${nextCh ? '' : 'disabled'} title="Episode Berikutnya">${ic.next}<span class="lbl">Berikutnya</span></button>
          <button id="btnFit" class="vtool" title="Ubah Tampilan Video">${ic.aspect}<span class="lbl">Tampilan</span></button>
          <button id="btnRotate" class="vtool vtool-rotate" title="Putar Layar">${ic.rotate}<span class="lbl">Putar Layar</span></button>
          <button id="btnFullscreen" class="vtool" title="Layar Penuh"><span id="fsIco">${ic.fsOn}</span><span class="lbl">Layar Penuh</span></button>
        </div>

        <div class="video-info-text">
          <div class="video-info-title">${esc(chapterTitle)}</div>
          <div class="video-info-sub">${esc(collTitle)}${videoChapters.length > 1 && currentIndex >= 0 ? ` &bull; Episode ${currentIndex + 1} dari ${videoChapters.length}` : ''}</div>
        </div>

        <div class="video-marks-panel">
          <div class="video-marks-head"><span>🔖 Penanda Menit</span><small id="markCount"></small></div>
          <div id="markList"></div>
        </div>

        <p class="video-hint">Ketuk 2x sisi kiri / kanan layar video untuk mundur / maju 10 detik.</p>
      </div>
    </div>`;

  const shell = document.getElementById('videoShell');
  const video = document.getElementById('videoEl');
  const wrap = document.getElementById('videoWrap');
  const overlay = document.getElementById('videoOverlay');
  const loading = document.getElementById('videoLoading');
  const nextCta = document.getElementById('nextCta');
  const seekBar = document.getElementById('seekBar');
  const timeCurrent = document.getElementById('timeCurrent');
  const timeDuration = document.getElementById('timeDuration');
  const iconPlay = document.getElementById('iconPlay');
  const iconPause = document.getElementById('iconPause');
  const btnSpeed = document.getElementById('btnSpeed');
  const speedIco = document.getElementById('speedIco');
  const btnLock = document.getElementById('btnLock');
  const btnLockFloating = document.getElementById('btnLockFloating');
  const toast = document.getElementById('videoToast');
  const tools = document.getElementById('videoTools');
  const infoPanel = document.getElementById('videoInfo');
  const bottomBar = document.getElementById('videoBottom');
  const fsIco = document.getElementById('fsIco');

  const speeds = [1, 1.25, 1.5, 2, 0.75];
  let speedIdx = 0;
  let isScrubbing = false;
  let hideTimer = null;
  let locked = false;
  let fitCover = false;
  let fs = false;
  let lastSeekAt = 0;
  let retryingSeek = false;

  // fmtTime = fungsi global (lihat atas file), dipakai juga oleh daftar penanda video.

  function showToast(msg) {
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toast.classList.remove('show'), 1600);
  }

  function setProgress() {
    if (!isFinite(video.duration) || video.duration <= 0) return;
    const pct = (seekBar.value / 1000) * 100;
    seekBar.style.setProperty('--p', pct + '%');
  }

  function showOverlay(autoHide) {
    if (locked) return;
    overlay.classList.remove('hide');
    clearTimeout(hideTimer);
    if (autoHide && !video.paused) {
      hideTimer = setTimeout(() => overlay.classList.add('hide'), 3500);
    }
  }
  function toggleOverlay() {
    if (locked) return;
    if (overlay.classList.contains('hide')) showOverlay(true);
    else { overlay.classList.add('hide'); clearTimeout(hideTimer); }
  }

  function updatePlayIcon() {
    const playing = !video.paused && !video.ended;
    iconPlay.style.display = playing ? 'none' : '';
    iconPause.style.display = playing ? '' : 'none';
  }

  function keepAwake(on) {
    try { if (typeof Android.keepScreenOn === 'function') Android.keepScreenOn(on); } catch (e) { /* abaikan */ }
  }

  function seekTo(t) {
    if (!isFinite(video.duration)) return;
    lastSeekAt = Date.now();
    video.currentTime = Math.max(0, Math.min(video.duration, t));
  }

  function seekBy(delta, side) {
    if (!isFinite(video.duration)) return;
    seekTo(video.currentTime + delta);
    showOverlay(true);
    const flash = document.getElementById(side === 'left' ? 'flashLeft' : 'flashRight');
    flash.classList.add('show');
    clearTimeout(flash._t);
    flash._t = setTimeout(() => flash.classList.remove('show'), 500);
  }

  // ---- Layar penuh: immersive + landscape (native) + video memenuhi layar ----
  function setFs(on) {
    fs = on;
    window.videoFsPref = on;
    shell.classList.toggle('is-fs', on);
    document.body.classList.toggle('video-fs', on);
    // Toolbar: di portrait tampil di panel bawah video, di layar penuh masuk ke dalam overlay.
    if (on) bottomBar.appendChild(tools);
    else infoPanel.insertBefore(tools, infoPanel.firstChild);
    fsIco.innerHTML = on ? ic.fsOff : ic.fsOn;
    try { if (typeof Android.setVideoFullscreen === 'function') Android.setVideoFullscreen(on); } catch (e) { /* abaikan */ }
    showOverlay(true);
  }
  document.getElementById('btnFullscreen').onclick = () => setFs(!fs);

  // ---- Putar layar: bolak-balik landscape <-> portrait (hanya saat layar penuh) ----
  document.getElementById('btnRotate').onclick = () => {
    if (!fs) { showToast('Masuk layar penuh dulu untuk memutar layar'); return; }
    let landscape = true;
    try { if (typeof Android.toggleOrientation === 'function') landscape = Android.toggleOrientation(); } catch (e) { /* abaikan */ }
    showToast(landscape ? 'Layar: Landscape' : 'Layar: Portrait');
    showOverlay(true);
  };

  // ---- Kunci layar: sembunyikan semua kontrol kecuali tombol buka-kunci mengambang ----
  function setLocked(v) {
    locked = v;
    wrap.classList.toggle('locked', locked);
    if (locked) {
      overlay.classList.add('hide');
      clearTimeout(hideTimer);
      btnLockFloating.classList.remove('hidden');
    } else {
      btnLockFloating.classList.add('hidden');
      showOverlay(true);
    }
  }
  btnLock.onclick = () => setLocked(true);
  btnLockFloating.onclick = () => setLocked(false);

  // ---- Penanda menit ----
  let marks = [];
  function loadMarks() {
    if (!chMeta.collection_id) return [];
    try {
      return JSON.parse(Android.listBookmarks(chMeta.collection_id)).filter(b => b.file_name === fileName);
    } catch (e) { return []; }
  }
  function renderMarks() {
    marks = loadMarks();
    const list = document.getElementById('markList');
    document.getElementById('markCount').textContent = marks.length ? marks.length + ' penanda' : '';
    list.innerHTML = marks.length
      ? marks.map(m => `
          <div class="mark-item">
            <button class="mark-go" data-t="${m.page_index}">
              <span class="mark-time">${fmtTime(m.page_index)}</span><span class="mark-txt">Lompat ke menit ini</span>
            </button>
            <button class="mark-del" data-id="${m.id}">Hapus</button>
          </div>`).join('')
      : '<p class="mark-empty">Belum ada penanda. Ketuk ikon 🔖 di video untuk menandai menit yang sedang diputar.</p>';
    list.querySelectorAll('.mark-go').forEach(b => b.onclick = () => {
      seekTo(parseInt(b.dataset.t));
      showToast('Lompat ke ' + fmtTime(parseInt(b.dataset.t)));
      if (video.paused) video.play().catch(() => {});
    });
    list.querySelectorAll('.mark-del').forEach(b => b.onclick = () => {
      if (confirm('Hapus penanda ini?')) { Android.deleteBookmark(parseInt(b.dataset.id)); renderMarks(); }
    });
    drawMarkTicks();
  }
  function drawMarkTicks() {
    const box = document.getElementById('seekMarks');
    if (!isFinite(video.duration) || video.duration <= 0) { box.innerHTML = ''; return; }
    box.innerHTML = marks
      .filter(m => m.page_index >= 0 && m.page_index <= video.duration)
      .map(m => `<i style="left:${(m.page_index / video.duration) * 100}%"></i>`).join('');
  }
  document.getElementById('btnVideoBookmark').onclick = () => {
    if (!chMeta.chapter_id) { showToast('Gagal menandai menit ini'); return; }
    const t = Math.floor(video.currentTime);
    Android.addBookmark(chMeta.chapter_id, chMeta.collection_id, t);
    renderMarks();
    showToast('🔖 Ditandai di ' + fmtTime(t));
    showOverlay(true);
  };
  renderMarks();

  // ---- Sembunyikan kontrol (chevron) ----
  document.getElementById('btnVideoBack').onclick = () => {
    try { video.pause(); } catch (e) { /* abaikan */ }
    if (history.length > 1) history.back();
    else nav(chMeta.collection_id ? '/detail/' + chMeta.collection_id : '/');
  };
  document.getElementById('btnCollapse').onclick = () => { overlay.classList.add('hide'); clearTimeout(hideTimer); };

  // ---- Play / pause ----
  document.getElementById('btnPlayPause').onclick = () => { if (video.paused) video.play().catch(() => {}); else video.pause(); };
  video.addEventListener('play', () => { updatePlayIcon(); nextCta.classList.add('hidden'); showOverlay(true); keepAwake(true); });
  video.addEventListener('pause', () => { updatePlayIcon(); showOverlay(false); keepAwake(false); });

  // ---- Mundur / maju 10 detik ----
  document.getElementById('btnRewind10').onclick = () => seekBy(-10, 'left');
  document.getElementById('btnForward10').onclick = () => seekBy(10, 'right');

  // ---- Ulangi video (loop) ----
  const btnRepeat = document.getElementById('btnRepeat');
  btnRepeat.onclick = () => {
    video.loop = !video.loop;
    btnRepeat.classList.toggle('active', video.loop);
    showToast(video.loop ? 'Ulangi video: aktif' : 'Ulangi video: mati');
    showOverlay(true);
  };

  // ---- Ubah tampilan video (contain <-> cover) ----
  document.getElementById('btnFit').onclick = () => {
    fitCover = !fitCover;
    video.style.objectFit = fitCover ? 'cover' : 'contain';
    showToast(fitCover ? 'Tampilan: penuhi layar' : 'Tampilan: sesuai video');
    showOverlay(true);
  };

  // ---- Episode sebelumnya / berikutnya ----
  if (prevCh) document.getElementById('btnPrevChapter').onclick = () => nav('/read/' + encodeURIComponent(prevCh.file_name));
  if (nextCh) {
    document.getElementById('btnNextChapter').onclick = () => nav('/read/' + encodeURIComponent(nextCh.file_name));
    const btnNextCta = document.getElementById('btnNextCta');
    if (btnNextCta) btnNextCta.onclick = () => nav('/read/' + encodeURIComponent(nextCh.file_name));
  }
  document.getElementById('btnReplayCta').onclick = () => { video.currentTime = 0; video.play().catch(() => {}); };

  // ---- Seek bar ----
  video.addEventListener('loadedmetadata', () => {
    loading.classList.remove('show');
    timeDuration.textContent = fmtTime(video.duration);
    drawMarkTicks();
    if (!retryingSeek && !isNaN(pageParam) && pageParam > 0 && pageParam < video.duration) {
      lastSeekAt = Date.now();
      video.currentTime = pageParam;
    }
    video.play().catch(() => { updatePlayIcon(); showOverlay(false); });
  });
  video.addEventListener('timeupdate', () => {
    if (isScrubbing || !isFinite(video.duration)) return;
    seekBar.value = (video.currentTime / video.duration) * 1000;
    timeCurrent.textContent = fmtTime(video.currentTime);
    setProgress();
  });
  seekBar.addEventListener('input', () => {
    isScrubbing = true;
    if (isFinite(video.duration)) timeCurrent.textContent = fmtTime((seekBar.value / 1000) * video.duration);
    setProgress();
    showOverlay(false);
  });
  function commitScrub() {
    if (!isScrubbing) return;
    if (isFinite(video.duration)) seekTo((seekBar.value / 1000) * video.duration);
    isScrubbing = false;
    showOverlay(true);
  }
  // 'change' menutup drag di kebanyakan WebView, tapi beberapa build Android kadang tidak
  // membakar 'change' saat jari dilepas cepat -- touchend/pointerup jadi jaring pengaman
  // supaya posisi seek selalu ter-commit dan bar tidak "nyangkut" di posisi drag.
  seekBar.addEventListener('change', commitScrub);
  seekBar.addEventListener('touchend', commitScrub);
  seekBar.addEventListener('pointerup', commitScrub);
  seekBar.addEventListener('mouseup', commitScrub);

  // ---- Buffering ----
  video.addEventListener('waiting', () => loading.classList.add('show'));
  video.addEventListener('playing', () => loading.classList.remove('show'));
  video.addEventListener('canplay', () => loading.classList.remove('show'));

  // ---- Selesai ----
  video.addEventListener('ended', () => {
    updatePlayIcon();
    keepAwake(false);
    if (!video.loop) { showOverlay(false); nextCta.classList.remove('hidden'); }
  });

  // ---- Kecepatan putar ----
  btnSpeed.onclick = () => {
    speedIdx = (speedIdx + 1) % speeds.length;
    video.playbackRate = speeds[speedIdx];
    speedIco.textContent = speeds[speedIdx] + 'X';
    showOverlay(true);
  };

  // ---- Tap kiri/tengah/kanan: single tap = toggle kontrol, double tap kiri/kanan = mundur/maju 10 detik ----
  const tapTimers = {};
  function handleZoneTap(zone) {
    if (locked) { btnLockFloating.classList.toggle('hidden'); return; }
    if (tapTimers[zone]) {
      clearTimeout(tapTimers[zone]);
      tapTimers[zone] = null;
      if (zone === 'left') seekBy(-10, 'left');
      else if (zone === 'right') seekBy(10, 'right');
      else toggleOverlay();
    } else {
      tapTimers[zone] = setTimeout(() => { tapTimers[zone] = null; toggleOverlay(); }, 280);
    }
  }
  document.getElementById('tapLeft').onclick = () => handleZoneTap('left');
  document.getElementById('tapMid').onclick = () => handleZoneTap('mid');
  document.getElementById('tapRight').onclick = () => handleZoneTap('right');

  // ---- Error: hanya tampilkan layar gagal utk error yg benar2 fatal (bukan gangguan sesaat saat seek) ----
  // ---- Pemulihan otomatis ----
  // Sumber video dimuat ulang (URL diberi parameter unik supaya WebView tidak memakai respons
  // gagal sebelumnya) lalu dilanjutkan dari posisi terakhir. Dipakai saat error sesaat, saat app
  // kembali dari background, dan oleh tombol "Coba Lagi".
  const baseSrc = Android.getChapterPlayUrl(fileName);
  let recoverAttempts = 0;
  let lastGoodTime = 0;
  let wasPlayingBeforeHide = false;
  video.addEventListener('timeupdate', () => { if (video.currentTime > 0) lastGoodTime = video.currentTime; });

  function recoverVideo(autoPlay) {
    const resumeAt = lastGoodTime || video.currentTime || 0;
    retryingSeek = true;
    loading.classList.add('show');
    // Parameter unik hanya untuk URL https virtual; file:// dan content:// dibuka apa adanya.
    video.src = baseSrc.startsWith('https:') ? baseSrc + (baseSrc.includes('?') ? '&' : '?') + 'r=' + Date.now() : baseSrc;
    video.load();
    video.addEventListener('loadedmetadata', function onceRecovered() {
      video.removeEventListener('loadedmetadata', onceRecovered);
      retryingSeek = false;
      if (isFinite(video.duration) && resumeAt > 0 && resumeAt < video.duration) {
        video.currentTime = resumeAt;
      }
      if (autoPlay) video.play().catch(() => {});
    }, { once: true });
  }

  // Video yang sudah jalan lancar = anggap pulih, jatah percobaan ulang direset.
  video.addEventListener('playing', () => { recoverAttempts = 0; });

  // App masuk background: jeda & ingat posisi. App kembali: kalau elemen video sempat rusak
  // (decoder dilepas sistem / stream terputus), muat ulang dari posisi terakhir.
  window.onVideoAppPaused = () => {
    if (!document.body.contains(video)) return;
    if (video.currentTime > 0) lastGoodTime = video.currentTime;
    wasPlayingBeforeHide = !video.paused && !video.ended;
    try { video.pause(); } catch (e) { /* abaikan */ }
  };
  window.onVideoAppResumed = () => {
    if (!document.body.contains(video)) return;
    if (video.error || video.readyState === 0) {
      recoverVideo(wasPlayingBeforeHide);
    } else if (wasPlayingBeforeHide) {
      video.play().catch(() => {});
    }
    wasPlayingBeforeHide = false;
  };

  // ---- Error: layar gagal HANYA setelah beberapa kali pemulihan otomatis benar-benar gagal ----
  video.addEventListener('error', () => {
    const err = video.error;
    // MEDIA_ERR_ABORTED (1) sering muncul sesaat saat request lama dibatalkan oleh seek baru -- bukan kegagalan nyata.
    if (err && err.code === 1) return;

    // Error network/decode sering cuma gangguan sesaat (app baru kembali dari background, request
    // Range lambat, dsb.), bukan file rusak. Coba pulihkan sampai 3x dengan jeda bertahap.
    if (recoverAttempts < 3) {
      recoverAttempts++;
      loading.classList.add('show');
      setTimeout(() => {
        if (!document.body.contains(video)) return;
        recoverVideo(true);
      }, 300 * recoverAttempts);
      return;
    }

    // Gagal fatal: keluar dari layar penuh dulu supaya halaman error tidak terjebak landscape/immersive.
    window.videoFsPref = false;
    document.body.classList.remove('video-fs');
    try { if (typeof Android.setVideoFullscreen === 'function') Android.setVideoFullscreen(false); } catch (e) { /* abaikan */ }
    keepAwake(false);
    loading.classList.remove('show');
    const codeInfo = err ? ` (kode ${err.code})` : '';
    app.innerHTML = `<div style="text-align:center; padding:60px 20px; color:#ffca28;">
      <h2>⚠️ Gagal Memutar Video</h2><p>Video tidak dapat dibuka${codeInfo}. Coba lagi, atau pastikan file masih ada di lokasi aslinya dan formatnya didukung (MP4 H.264).</p><br>
      <a href="javascript:void(0)" id="btnRetryVideo" class="btn-back" style="margin-right:10px;">↻ Coba Lagi</a>
      <a href="javascript:history.back()" class="btn-back">Kembali</a></div>`;
    document.getElementById('btnRetryVideo').onclick = () => { location.reload(); };
  });

  // Pindah episode saat sedang layar penuh -> tetap layar penuh di episode berikutnya.
  if (window.videoFsPref) setFs(true);

  loading.classList.add('show');
  showOverlay(true);
}

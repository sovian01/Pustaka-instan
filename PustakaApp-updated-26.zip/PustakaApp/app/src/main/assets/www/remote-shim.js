// ============================================================================
// remote-shim.js -- dipakai HANYA saat Pustaka dibuka lewat browser (pengguna lain yang
// membuka http://IP-HP:PORT). Di dalam app Android, jembatan asli `window.Android`
// sudah ada sejak halaman dimuat, jadi file ini langsung berhenti.
//
// app.js memanggil Android.xxx() secara SINKRON (hasil String JSON). Di sini panggilan itu
// diteruskan ke server di HP lewat XMLHttpRequest sinkron ke /rpc.
//   - Method baca: selalu boleh.
//   - Method tulis: server menolak (403) sampai pemilik HP menyetujui "izin edit".
// ============================================================================
(function () {
  if (window.Android) return;

  // ---- identitas klien (acak, disimpan di browser ini) ----
  function makeId() {
    const a = new Uint8Array(16);
    if (window.crypto && crypto.getRandomValues) crypto.getRandomValues(a);
    else for (let i = 0; i < a.length; i++) a[i] = Math.floor(Math.random() * 256);
    return Array.from(a, b => b.toString(16).padStart(2, '0')).join('');
  }
  let CID = null;
  try { CID = localStorage.getItem('pustaka_client_id'); } catch (e) {}
  if (!CID || !/^[a-f0-9]{16,64}$/.test(CID)) {
    CID = makeId();
    try { localStorage.setItem('pustaka_client_id', CID); } catch (e) {}
  }

  // ---- status izin (diperbarui oleh polling) ----
  let st = { canEdit: false, pending: false, denied: false, offline: false };

  // ---- RPC sinkron ----
  function rpc(method, args) {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/rpc', false);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('X-Client', CID);
    const clean = args.map(v => (v === undefined || v === null) ? '' : v);
    try {
      xhr.send(JSON.stringify({ m: method, a: clean }));
    } catch (e) {
      st.offline = true; renderBar();
      throw new Error('Tidak bisa terhubung ke server Pustaka (HP pemilik mati / beda jaringan?).');
    }
    if (xhr.status === 401) { location.reload(); throw new Error('locked'); }
    if (xhr.status === 403) {
      alert('Kamu hanya bisa melihat.\nUntuk mengubah data, tekan "Minta izin edit" di bagian atas halaman dan tunggu pemilik menyetujui.');
      throw new Error('forbidden');
    }
    if (xhr.status !== 200) throw new Error('Server error ' + xhr.status);
    return xhr.responseText;
  }

  const A = {};
  ['listCollections', 'getDetail', 'listCategories', 'listBookmarks',
   'getChapterInfo', 'getChapterIdByFileName',
   'addCollection', 'editCollection', 'deleteCollection', 'updateItemCategories',
   'addCategory', 'deleteCategory', 'editChapters', 'deleteChapter',
   'addBookmark', 'deleteBookmark'
  ].forEach(m => { A[m] = (...args) => rpc(m, args); });

  A.hasManageStoragePermission = () => rpc('hasManageStoragePermission', []) === 'true';

  // ---- URL media: dilayani langsung oleh server (sama persis dengan yang dipakai di dalam app) ----
  const enc = encodeURIComponent;
  A.getCoverUrl = (p) => '/cover/' + enc(p);
  A.getChapterRawUrl = (f) => '/chapter/' + enc(f);
  A.getChapterPlayUrl = A.getChapterRawUrl;
  A.getCbzPageUrl = (f, i) => '/cbzpage/' + enc(f) + '/' + i;
  A.getPdfPageUrl = (f, i) => '/pdfpage/' + enc(f) + '/' + i;

  // ---- hal yang hanya bisa dilakukan di HP pemilik ----
  function hostOnly(msg) { alert(msg || 'Fitur ini hanya bisa dipakai langsung di HP pemilik.'); }
  function later(fn) { setTimeout(fn, 0); }

  A.addChapter = () => {
    hostOnly('Menambah chapter hanya bisa dilakukan dari HP pemilik (file chapter tersimpan di HP itu).');
    return JSON.stringify({ error: 'host_only' });
  };
  A.pickChapterSourceFolder = (id) => {
    hostOnly('Memilih folder chapter hanya bisa dari HP pemilik.');
    later(() => window.onNativeFolderPicked && window.onNativeFolderPicked(id, false, ''));
  };
  A.pickChapterFile = (id) => {
    hostOnly('Menambah chapter hanya bisa dilakukan dari HP pemilik.');
    later(() => window.onNativeChapterFilePicked && window.onNativeChapterFilePicked(id, false, '', ''));
  };
  A.pickChapterFiles = (id) => {
    hostOnly('Menambah chapter hanya bisa dilakukan dari HP pemilik.');
    later(() => window.onNativeChapterFilesPicked && window.onNativeChapterFilesPicked(id, false, '[]'));
  };
  A.requestManageStoragePermission = () => hostOnly('Izin penyimpanan hanya bisa diatur di HP pemilik.');
  A.exportBackup = (id) => {
    hostOnly('Backup hanya bisa dilakukan dari HP pemilik.');
    later(() => window.onBackupExported && window.onBackupExported(id, false));
  };
  A.importBackup = (id) => {
    hostOnly('Restore backup hanya bisa dilakukan dari HP pemilik.');
    later(() => window.onBackupImported && window.onBackupImported(id, false));
  };
  A.openWithExternalApp = (f) => {
    window.open('/chapter/' + enc(f), '_blank');
    return JSON.stringify({ success: true });
  };

  // ---- upload cover: pakai <input type=file> browser, kirim base64 seperti versi native ----
  A.pickImage = (id) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    let settled = false;
    const done = (b64, name) => {
      if (settled) return;
      settled = true;
      window.onNativeFilePicked && window.onNativeFilePicked(id, b64, name);
    };
    input.onchange = () => {
      const f = input.files && input.files[0];
      if (!f) return done(null, null);
      const r = new FileReader();
      r.onload = () => {
        const s = String(r.result || '');
        done(s.substring(s.indexOf(',') + 1), f.name.replace(/'/g, ''));
      };
      r.onerror = () => done(null, null);
      r.readAsDataURL(f);
    };
    input.oncancel = () => done(null, null);
    input.click();
  };

  // ---- layar penuh / rotasi / layar tetap menyala: padanan versi browser ----
  function goFullscreen(on) {
    try {
      if (on && !document.fullscreenElement && document.documentElement.requestFullscreen) {
        document.documentElement.requestFullscreen().catch(() => {});
      } else if (!on && document.fullscreenElement && document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      }
    } catch (e) {}
  }
  function lockOrientation(mode) {
    try {
      if (!screen.orientation) return;
      if (mode) screen.orientation.lock(mode).catch(() => {});
      else screen.orientation.unlock();
    } catch (e) {}
  }
  A.toggleFullscreen = () => { const on = !document.fullscreenElement; goFullscreen(on); return on; };
  A.exitFullscreen = () => goFullscreen(false);
  A.setVideoFullscreen = (enabled) => { goFullscreen(!!enabled); lockOrientation(enabled ? 'landscape' : null); };
  let portrait = false;
  A.toggleOrientation = () => { portrait = !portrait; lockOrientation(portrait ? 'portrait' : 'landscape'); return !portrait; };
  let wake = null;
  A.keepScreenOn = (enabled) => {
    try {
      if (enabled && navigator.wakeLock && !wake) {
        navigator.wakeLock.request('screen').then(w => { wake = w; w.addEventListener('release', () => { wake = null; }); }).catch(() => {});
      } else if (!enabled && wake) { wake.release(); wake = null; }
    } catch (e) {}
  };

  window.Android = A;
  window.PUSTAKA_REMOTE = true;

  // ==========================================================================
  // Bar status + tombol "Minta izin edit"
  // ==========================================================================
  let bar = null, barMsg = null, barBtn = null;

  function buildBar() {
    bar = document.createElement('div');
    bar.style.cssText = 'position:sticky;top:0;z-index:9999;display:flex;gap:8px;align-items:center;' +
      'justify-content:space-between;padding:8px 12px;font:13px/1.3 sans-serif;color:#fff;';
    barMsg = document.createElement('span');
    barBtn = document.createElement('button');
    barBtn.type = 'button';
    // style.css memberi width:100% ke semua <button>; tombol ikon ini harus kecil.
    barBtn.style.cssText = 'width:auto;flex:none;padding:5px 10px;border:none;border-radius:14px;' +
      'background:#ffca28;color:#000;font-weight:bold;font-size:12px;cursor:pointer;';
    barBtn.onclick = requestEdit;
    bar.appendChild(barMsg);
    bar.appendChild(barBtn);
    document.body.insertBefore(bar, document.body.firstChild);
    renderBar();
  }

  function renderBar() {
    if (!bar) return;
    let bg, msg, btn = '';
    if (st.offline) { bg = '#8a2b2b'; msg = '⚠️ Terputus dari server Pustaka'; }
    else if (st.canEdit) { bg = '#1f6b3a'; msg = '✏️ Kamu boleh mengedit'; }
    else if (st.pending) { bg = '#6b5a1f'; msg = '⏳ Menunggu persetujuan pemilik…'; }
    else if (st.denied) { bg = '#8a2b2b'; msg = '🚫 Permintaan izin edit ditolak'; btn = 'Minta lagi'; }
    else { bg = '#33415c'; msg = '👁 Mode lihat saja'; btn = '✏️ Minta izin edit'; }
    bar.style.background = bg;
    barMsg.textContent = msg;
    barBtn.textContent = btn;
    barBtn.style.display = btn ? '' : 'none';
    syncVisibility();
  }

  // Di dalam pembaca (reader) bar disembunyikan supaya tidak menutupi kontrol.
  function syncVisibility() {
    if (!bar) return;
    bar.style.display = location.hash.startsWith('#/read/') ? 'none' : 'flex';
  }
  window.addEventListener('hashchange', syncVisibility);

  async function poll() {
    try {
      const r = await fetch('/api/status', { headers: { 'X-Client': CID }, cache: 'no-store' });
      if (r.status === 401) { location.reload(); return; } // PIN diganti pemilik / sesi tidak berlaku lagi
      const j = await r.json();
      st = { canEdit: !!j.can_edit, pending: !!j.pending, denied: !!j.denied, offline: false };
    } catch (e) {
      st.offline = true;
    }
    renderBar();
  }

  async function requestEdit() {
    let name = '';
    try { name = localStorage.getItem('pustaka_remote_name') || ''; } catch (e) {}
    name = (prompt('Nama kamu (supaya pemilik tahu siapa yang meminta izin):', name) || '').trim();
    if (!name) return;
    try { localStorage.setItem('pustaka_remote_name', name); } catch (e) {}
    try {
      await fetch('/api/request-edit', {
        method: 'POST',
        headers: { 'X-Client': CID, 'Content-Type': 'application/json' },
        body: JSON.stringify({ name })
      });
    } catch (e) {}
    poll();
  }

  function init() { buildBar(); poll(); setInterval(poll, 3000); }
  if (document.body) init();
  else window.addEventListener('DOMContentLoaded', init);
})();
